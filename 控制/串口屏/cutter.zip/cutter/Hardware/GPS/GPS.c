/*
 * GPS.c
 *
 *  Created on: Nov 17, 2023
 *      Author: 28079
 */
#include "GPS.h"
#include "usart.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"

GPSData gps_data;

uint8_t Uart1_RX_data[GPS_buff];//接收数据缓存，大小可设
void GPS_IT_open(void)
{
	//HAL_UART_Receive_IT(&huart1, (uint8_t *)&Uart1_RX_data, 1);  //普通的串口接收中断，开始接收数据
	HAL_UARTEx_ReceiveToIdle_IT(&huart3, Uart1_RX_data, GPS_buff);//调用接收空闲中断
}

/*数据预处理*/
void process_gps_data(uint8_t *rxData, size_t len, GPSData *data) {
//    char *token;
    char *line = strtok((char *)rxData, "\r\n");

    while (line != NULL) {
        gps_parse(line, data);
        line = strtok(NULL, "\r\n");
    }
}

//接收空闲中断回调函数
void GPS_usart1_Callback()
{

	/**
	 **处理数据**
	 **其中Size是接收到的数据长度，Uart1_RX_data是接收到数据的缓存
	 **/

	process_gps_data(Uart1_RX_data, sizeof(Uart1_RX_data), &gps_data);

	HAL_UARTEx_ReceiveToIdle_IT(&huart3, Uart1_RX_data, GPS_buff);//开启接收空闲中断
}


//返回的是第num个逗号后的位置
static int GetComma(int num,char *str)
{
	int i,j=0;
	int len=strlen(str);
	for(i=0;i<len;i++)
	{
		if(str[i]==',')j++;
		if(j==num)return i+1;	//返回当前找到的逗号位置的下一个位置
	}
	return 0;
}

static double get_double_number(char *s)
{
	char buf[128];
	int i;
	double rev;
	i=GetComma(1,s);    //得到数据长度
	strncpy(buf,s,i);
	buf[i]=0;			//加字符串结束标志
	rev=atof(buf);		//字符串转float
	return rev;
}

static void UTC2BTC(date_time *GPS)
{
//***************************************************
//如果秒号先出,再出时间数据,则将时间数据+1秒
		GPS->second++; //加一秒
		if(GPS->second>59){
			GPS->second=0;
			GPS->minute++;
			if(GPS->minute>59){
				GPS->minute=0;
				GPS->hour++;
			}
		}

//***************************************************
		GPS->hour+=8;		//北京时间跟UTC时间相隔8小时
		if(GPS->hour>23)
		{
			GPS->hour-=24;
			GPS->day+=1;
			if(GPS->month==2 ||GPS->month==4 ||GPS->month==6 ||GPS->month==9 ||GPS->month==11 ){
				if(GPS->day>30){			//上述几个月份是30天每月，2月份还不足30
			   		GPS->day=1;
					GPS->month++;
				}
			}
			else{
				if(GPS->day>31){			//剩下的几个月份都是31天每月
			   		GPS->day=1;
					GPS->month++;
				}
			}
			if(GPS->year % 4 == 0 ){//
		   		if(GPS->day > 29 && GPS->month ==2){		//闰年的二月是29天
		   			GPS->day=1;
					GPS->month++;
				}
			}
			else{
		   		if(GPS->day>28 &&GPS->month ==2){		//其他的二月是28天每月
		   			GPS->day=1;
					GPS->month++;
				}
			}
			if(GPS->month>12){
				GPS->month-=12;
				GPS->year++;
			}
		}
}

int get_field_value(char *buf, int field) {
    int start = GetComma(field - 1, buf);
    int end = GetComma(field, buf) - 1; // 减1是因为GetComma返回的是逗号后一个字符的位置
    char field_buf[10]; // 假设字段值不会超过10个字符
    strncpy(field_buf, buf + start, end - start);
    field_buf[end - start] = '\0'; // 添加字符串结束符
    return atoi(field_buf); // 将字符串转换为整数
}

void gps_parse(char *line,GPSData *GPS)
{
	int tmp;
	char b,c;
	char* buf=line;
	b=buf[4];
	c=buf[5];

	if(b=='M' && c=='C'){//"GNRMC"
		GPS->D.hour   =(buf[ 7]-'0')*10+(buf[ 8]-'0');
		GPS->D.minute =(buf[ 9]-'0')*10+(buf[10]-'0');
		GPS->D.second =(buf[11]-'0')*10+(buf[12]-'0');
		tmp = GetComma(9,buf);		//得到第9个逗号的下一字符序号
		GPS->D.day    =(buf[tmp+0]-'0')*10+(buf[tmp+1]-'0');
		GPS->D.month  =(buf[tmp+2]-'0')*10+(buf[tmp+3]-'0');
		GPS->D.year   =(buf[tmp+4]-'0')*10+(buf[tmp+5]-'0')+2000;
		//------------------------------
		GPS->status   =buf[GetComma(2,buf)];		//状态
		GPS->latitude =get_double_number(&buf[GetComma(3,buf)]) / 100;	//纬度
		GPS->NS       =buf[GetComma(4,buf)];				//南北纬
		GPS->longitude=get_double_number(&buf[GetComma(5,buf)]) / 100;	//经度
		GPS->EW       =buf[GetComma(6,buf)];				//东西经
		GPS->speed    =get_double_number(&buf[GetComma(7,buf)]);   //速率，000.0-999.9节
		GPS->course   =get_double_number(&buf[GetComma(8,buf)]);   //航向，000.0-359.9度
		UTC2BTC(&GPS->D);						//转北京时间
	}
	if(b=='G' && c=='A'){ //"$GNGGA"
		GPS->satellites = get_field_value(buf, 8); // 提取并转换第8个字段的值，卫星数
	}
	if(b=='H' && c=='S') //"$GNTHS"
	{
		GPS->ths = get_double_number(&buf[GetComma(1,buf)]);   //航向，000.0-359.9度
	}
}

