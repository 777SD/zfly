/*
 * GPSP.h
 *
 *  Created on: Apr 6, 2024
 *      Author: SGM
 */

#ifndef PRINT_GPSP_H_
#define PRINT_GPSP_H_
#include "main.h"

void GPSP_IT_Open();
void wireless_UARTE2_Callback(void);


typedef struct{

	 double	latitude;   //纬度
	 double longitude;  //经度
	 int16_t ths;		//和芯星通双天线航向
	 int satellites;    // 卫星数
	 char mode;			//模式

	 int16_t longitude_cm_error;
	 int16_t latitude_cm_error;
	 int16_t feedback_ths;
	 double latitude_cm;
	 double longitude_cm;
}GPSP;

enum{
	tracking_task,
	mow_task,
	manual_mode,
	auto_mode
};

extern GPSP gpsp;


#endif /* PRINT_GPSP_H_ */
