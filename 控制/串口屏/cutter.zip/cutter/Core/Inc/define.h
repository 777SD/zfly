/*
 * define.h
 *
 *  Created on: Nov 18, 2023
 *      Author: 28079
 */

#ifndef SRC_DEFINE_H_
#define SRC_DEFINE_H_

enum
{
	false = 0,
	true,

	on = 0,
	off
};

#endif /* SRC_DEFINE_H_ */
