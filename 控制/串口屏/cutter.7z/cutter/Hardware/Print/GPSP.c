/*
 * GPSP.c
 *
 *  Created on: Apr 6, 2024
 *      Author: SGM
 */
#include "GPSP.h"
#include "GPS.h"
#include "main.h"
#include "stdio.h"
#include "usart.h"
#include "string.h"
#include "stdlib.h"

GPSP gpsp;
uint8_t PC_buf[1] = {0};
char buf[256];	//默认256
uint8_t flag=0;
uint8_t i=0;
void GPSP_IT_Open()
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart2,PC_buf,1);//接受的数据存到PC_buf中 长度为1(IDLE标志位能解决一次性接收大量数据)
}

void wireless_UARTE2_Callback(void)
{

	if(PC_buf[0] == 0xE1 || flag==1)//ths
	{
		if(PC_buf[0] == 0xE2)
		{
			gpsp.ths=atof(buf);
			flag=2;
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中第一个要为指针变量
			i=0;
			return ;// goto out 退出所在的函数
		}
		if(flag ==1 )
		{
			buf[i++]=PC_buf[0];
		}
		flag=1;


	}else if(flag==2 )//lon
	{
		if(PC_buf[0]==0xE3)
		{
			gpsp.longitude=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=3;
			i=0;
			return ;// goto out
		}
		buf[i++]=PC_buf[0];

	}else if(flag==3)//lat
	{
		if(PC_buf[0]==0xE4)
		{
			gpsp.latitude=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=4;
			i=0;
			return ;// goto out
		}
		buf[i++]=PC_buf[0];

	}else if(flag==4)//mode
	{
		switch(PC_buf[0]){
			case 0x02: gpsp.mode = manual_mode;	break;
			case 0x01: gpsp.mode = mow_task;		break;
			case 0x03: gpsp.mode = auto_mode;		break;
			case 0x00: gpsp.mode = tracking_task;		break;
			default:   gpsp.mode = manual_mode;		break;
		}
		if(PC_buf[0]==0xE5)
		{
			flag=5;
			i=0;
			return ;// goto out
		}

	}else if(flag == 5)//sat
	{
		if(PC_buf[0]==0xE6)
		{
			gpsp.satellites=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=6;
			i=0;
			return ;// goto out
		}
		if(PC_buf[0]==0xE5)
		{
			buf[i++]=PC_buf[0];
			return ;// goto out
		}

	}else if(flag == 6)//lon_err
	{
		if(PC_buf[0]==0xE7)
		{
			gpsp.longitude_cm_error=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=7;
			i=0;
			return ;// goto out
		}
		buf[i++]=PC_buf[0];

	}else if(flag == 7)//lat_err
	{
		if(PC_buf[0]==0xE8)
		{
			gpsp.latitude_cm_error=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=8;
			i=0;
			return ;// goto out
		}
		buf[i++]=PC_buf[0];
	}else if(flag == 8)//feedback_ths
	{
		if(PC_buf[0]==0xE9)
		{
			gpsp.feedback_ths=atof(buf);
			memset(buf,0,sizeof(buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
			flag=0;
			i=0;
			return ;// goto out
		}
		buf[i++]=PC_buf[0];

	}


}





