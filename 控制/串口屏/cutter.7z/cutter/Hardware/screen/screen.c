/*
 * screen.c
 *
 *  Created on: Apr 6, 2024
 *      Author: SGM
 */
#include "GPSP.h"
#include "GPS.h"
#include "main.h"
#include "stdio.h"
#include "usart.h"
#include "string.h"
#include "stdlib.h"

uint8_t j=0;
uint8_t screen_buf[40]={0};
uint8_t screen_rx_buf[1]={0};
uint8_t screen_flag = 0;

/*
uint8_t save_flag = 0;
char save_buf[30] = {0};
double save_latitude[4]={0};//纬度
double save_longitude[4]={0};//经度
int si=0;
*/

void screen_IT_Open()
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart4,(uint8_t *)screen_rx_buf,1);//清除标志位
}

void screen_usart3_Callback()
{
	if(screen_rx_buf[0] == 0xEE || screen_rx_buf[0] == 0xEA || screen_flag == 1){
		screen_buf[j++] = screen_rx_buf[0];
		screen_flag = 1;
	}

	if(screen_rx_buf[0] == 0xFF && screen_flag == 1){
		HAL_UART_Transmit(&huart2, screen_buf, j, 10);
		memset(screen_buf,0,sizeof(screen_buf));//清空数组数据 ，该函数在string.h中，其中a要为指针变量
		j = 0;
		screen_flag = 0;
	}

/*
	if(screen_rx_buf[0] == 0xD1 || save_flag==1)//存储保存的点位信息
	{
			if(screen_rx_buf[0] == 0xE1)
			{
				save_latitude[si] = atof(save_buf);
				save_flag=2;
				memset(save_buf,0,sizeof(save_buf));//清空数组数据 ，该函数在string.h中，其中第一个要为指针变量
				j=0;
				return ;// goto out 退出所在的函数
			}
			if(save_flag ==1 )
			{
				save_buf[j++]=screen_rx_buf[0];//转存
			}
			save_flag=1;


	}else if(save_flag == 2)
	{
		if(screen_rx_buf[0] == 0xDE)
		{
			save_longitude[si] = atof(save_buf);
			save_flag=0;
			memset(save_buf,0,sizeof(save_buf));//清空数组数据 ，该函数在string.h中，其中第一个要为指针变量
			j=0;
			si++;
			if(si==4)si=0;
			return ;// goto out 退出所在的函数
		}
		if(save_flag ==2 )
		{
			save_buf[j++]=screen_rx_buf[0];//转存
		}
	}
*/

}

void screen_sendBuf(void)
{

	printf("\n");
//串口屏激活刷新
	printf("cardatashow.t11.txt=\"%d\"\xff\xff\xff",gpsp.ths);//双天线航向

//数据正式发送
	printf("cardatashow.t13.txt=\"%f\"\xff\xff\xff",gpsp.latitude);//纬度
	printf("cardatashow.t12.txt=\"%f\"\xff\xff\xff",gpsp.longitude);//经度
	printf("cardatashow.t11.txt=\"%d\"\xff\xff\xff",gpsp.ths);//双天线航向
	switch(gpsp.mode){
		case manual_mode:		printf("cardatashow.t14.txt=\"manual_mode\"\xff\xff\xff");		break;
		case auto_mode:			printf("cardatashow.t14.txt=\"auto_mode\"\xff\xff\xff");		break;
		case tracking_task:		printf("cardatashow.t14.txt=\"tracking_task\"\xff\xff\xff");	break;
		case mow_task:			printf("cardatashow.t14.txt=\"mow_task\"\xff\xff\xff");		break;
	}
	printf("cardatashow.t23.txt=\"%d\"\xff\xff\xff",gpsp.satellites);//卫星数
	printf("cardatashow.t18.txt=\"%d\"\xff\xff\xff",gpsp.longitude_cm_error);
	printf("cardatashow.t19.txt=\"%d\"\xff\xff\xff",gps_data.latitude_cm_error);
	printf("cardatashow.t20.txt=\"%d\"\xff\xff\xff",gpsp.feedback_ths);

	printf("dadian.t41.txt=\"%f\"\xff\xff\xff",gps_data.longitude*1000);//经度
	printf("dadian.t42.txt=\"%f\"\xff\xff\xff",gps_data.latitude*1000);//纬度
	printf("dadian.t43.txt=\"%d\"\xff\xff\xff ",gps_data.satellites);//卫星数

}
