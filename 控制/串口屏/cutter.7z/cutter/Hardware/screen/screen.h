/*
 * screen.h
 *
 *  Created on: Apr 6, 2024
 *      Author: SGM
 */

#ifndef SCREEN_SCREEN_H_
#define SCREEN_SCREEN_H_


void screen_IT_Open();
void screen_usart3_Callback();
void screen_sendBuf(void);

#endif /* SCREEN_SCREEN_H_ */
