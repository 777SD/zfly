/*
 * MyJSON.h
 *
 *  Created on: 2024年1月4日
 *      Author: 28079
 */

#ifndef MYJSON_MYJSON_H_
#define MYJSON_MYJSON_H_

char* bluetooth_to_Json(void);
void to_bluetooth_Json(const char* jsonString);

#endif /* MYJSON_MYJSON_H_ */
