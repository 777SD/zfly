/*
 * MyJSON.c
 *
 *  Created on: 2024年1月4日
 *      Author: 28079
 */

#include "MyJSON.h"
#include "cJSON.h"
#include <stdlib.h>
#include "string.h"
#include "stdio.h"
#include "planning.h"
#include "usart.h"
#include "GPS.h"
#include "manual_ctrl.h"
#include "auto_crtl.h"

/*(解析json数据)*/
void to_bluetooth_Json(const char* jsonString)
{

    cJSON* root = cJSON_Parse(jsonString);
    if (root == NULL)
    {
        return;
    }

    cJSON* msgJson   		= cJSON_GetObjectItem(root, "msg");
    cJSON* position_lat   	= cJSON_GetObjectItem(msgJson, "position_lat");
    cJSON* position_lon    	= cJSON_GetObjectItem(msgJson, "position_lon");


    position.latitude = position_lat->valuedouble;
    position.longitude = position_lon->valuedouble;


    cJSON_Delete(root);
}

/*返回状态(发送json数据)*/
char* bluetooth_to_Json(void)
{
	char* jsonString;

	/* 创建一个JSON数据对象(链表头结点) */
	cJSON* root = cJSON_CreateObject();

    /* 添加一个嵌套的JSON数据（添加一个链表节点） */
    cJSON* msg = cJSON_CreateObject();
    cJSON_AddNumberToObject(msg, "ths", gps_data.ths);									//
    cJSON_AddNumberToObject(msg, "feedback_ths", gps_data.feedback_ths);				//
    cJSON_AddNumberToObject(msg, "latitude", gps_data.latitude);						//
    cJSON_AddNumberToObject(msg, "longitude", gps_data.longitude);						//
    cJSON_AddNumberToObject(msg, "latitude_cm_error", gps_data.latitude_cm_error);		//
    cJSON_AddNumberToObject(msg, "longitude_cm_error", gps_data.longitude_cm_error);	//
    cJSON_AddNumberToObject(msg, "satellites", gps_data.satellites);					//
    cJSON_AddNumberToObject(msg, "auto_mode", auto_mode);
    cJSON_AddNumberToObject(msg, "PIT", pitch_value);
    cJSON_AddNumberToObject(msg, "YAW", yaw_value);
    cJSON_AddNumberToObject(msg, "THR", thr_value);

    cJSON_AddItemToObject(root, "msg", msg);

    /* 打印JSON对象(整条链表)的所有数据 */
    jsonString = cJSON_Print(root);

    cJSON_Delete(root);
    free(jsonString);

    return jsonString;
}

