/*
 * MY_math.c
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */
#include "MY_math.h"
#include <math.h>

#define PI 3.14159265358979323846
#define DEGREE_TO_RADIAN(degree) ((degree) * (PI / 180.0))
#define EARTH_RADIUS_IN_KM 6371.0
#define METERS_PER_DEGREE 111320.0


// 计算给定纬度下，一分经纬度代表的距离（以厘米为单位）
void calculateDistancePerMinute(double latitude, double *distancePerMinLat, double *distancePerMinLon) {
    // 纬度的长度（以厘米为单位）
    *distancePerMinLat = (METERS_PER_DEGREE / 60) * 100;

    // 经度的长度随纬度变化（以厘米为单位）
    *distancePerMinLon = (cos(DEGREE_TO_RADIAN(latitude)) * METERS_PER_DEGREE / 60) * 100;
}

/*
 * 	判断当前值是否在目标值范围内
 */
int8_t judging_range(double feedback_value,double target_value,double range)
{
	if(target_value - range > feedback_value){			//目标值下限大于当前值
		return Less_than_range;
	}else if(target_value + range < feedback_value){	//目标值上限小于当前值
		return  Greater_than_range;
	}else{			//当前值在目标值±range范围内
		return In_range;
	}

	return In_range;
}

/**********************************************************************
* 名    称：float my_deadzone(float x,float ref,float zoom)
* 功    能：添加死区
* 入口参数：x:原始数据 ref:mid-value zoom:dead zone
* 出口参数：data with dead zone added
* 说    明：经过该函数处理，数据输出为-(500-deadband)~0~（500-deadband）
**********************************************************************/
float data_to_deadzone(float x,float ref,float zoom)
{
    float t;
    if(x>ref)
    {
        t = x - zoom;   //x不管在ref~ref+zoom之间怎么变,输出t始终为ref
        if(t<ref)
        {
            t = ref;
        }
    }
    else
    {
        t = x + zoom;
        if(t>ref)
        {
            t = ref;
        }
    }
  return (t);
}

/**********************************************************************
* 名    称：
* 功    能：
* 入口参数：
* 出口参数：
* 说    明：失真限制，大的小的都掐掉
**********************************************************************/
float limit(float data, float min, float max)
{
    data = data > max ? max : data;
    data = data < min ? min : data;
    return data;
}

/*
 * 取绝对值
 */
float absolute(float value)
{
	if(value >= 0){
		return value;
	}else{
		return -value;
	}


}

float* change_data(float data)
{
	static float result[8] = {0};

	for(uint8_t i = 0;i<8;i++){
		if(i < 7){
			result[i] = result[i+1];
		}else result[i] = data;
	}

	return result;
 }

//滑动平均算法
float moving_average(float* data)
{
	static float sum = 0;
	static float value = 0;

	sum = 0;
	for(uint8_t i = 0;i<8;i++){
		sum += data[i];
	}
	value = sum/8.0f;

	return value;
}


/*
 * 高通滤波函数:highPassFilter函数接受当前输入的加速度值input和前一个时间步的滤波结果prevOutput作为参数，并返回滤波后的结果output。滤波器的效果由ALPHA参数控制
 * input: 当前输入的值
 * prevInput:上一个输入的值
 * prevOutput: 上一个输出的值，也可以看作是前一个时间步的滤波结果
 * output: 当前输出的加速度值，即经过高通滤波后的结果
 * alpha: 高通滤波器的系数，用于控制滤波效果的强度。它的取值范围通常是0到1之间。较大的值表示滤波器对低频分量的抑制更强，较小的值表示滤波器对低频分量的抑制更弱
 *
 * 一阶高通滤波器传函为：RC*S/(1+RC*S)------->y[i] = α * y[i-1] + α * (x[i] - x[i-1])	α = RC/(T+RC)
 */
float highPassFilter(float input, float prevInput, float prevOutput,float alpha)
{
//	float RC = 1.0f/(2*M_PI*cutoffFrequency);
//	float dt = 1.0 / sampleRate;
//	float alpha = RC / (RC + dt);
    float output = alpha * (prevOutput + input - prevInput);
    return output;
}






