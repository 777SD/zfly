/*
 * MY_math.h
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */

#ifndef MY_MATH_MY_MATH_H_
#define MY_MATH_MY_MATH_H_

#include "main.h"

enum
{
	Less_than_range ,
	Greater_than_range ,
	In_range ,

	range_judge
};

int8_t judging_range(double feedback_value,double target_value,double range);
void calculateDistancePerMinute(double latitude, double *distancePerMinLat, double *distancePerMinLon);
float data_to_deadzone(float x,float ref,float zoom);
float limit(float data, float min, float max);
float absolute(float value);

float* change_data(float data);
float moving_average(float* data);
float highPassFilter(float input, float prevInput, float prevOutput,float alpha);

#endif /* MY_MATH_MY_MATH_H_ */
