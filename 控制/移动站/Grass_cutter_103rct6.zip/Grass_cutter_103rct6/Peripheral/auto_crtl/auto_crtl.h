/*
 * auto_crtl.h
 *
 *  Created on: Nov 24, 2023
 *      Author: 28079
 */

#ifndef AUTO_CRTL_AUTO_CRTL_H_
#define AUTO_CRTL_AUTO_CRTL_H_

#include "main.h"

#define origin_latitude		0
#define origin_longitude	0
#define	corner_latitude		 34.351742797
#define corner_longitude	113.404717053
#define ready_latitude		0
#define ready_longitude		0

enum
{
	tracking_task ,				//航点追踪	任务
	mow_task ,					//割草	任务

	manual_mode ,				//手动模式
	auto_mode					//自动模式
};
extern uint8_t control_mode;
extern uint8_t auto_control_mode;
extern uint16_t mower_width;

_Bool auto_mode_check();
void mow_task_ctrl(void);
void auto_crtl();

#endif /* AUTO_CRTL_AUTO_CRTL_H_ */
