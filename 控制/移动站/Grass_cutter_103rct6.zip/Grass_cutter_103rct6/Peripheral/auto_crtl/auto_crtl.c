/*
 * auto_crtl.c
 *
 *  Created on: Nov 24, 2023
 *      Author: 28079
 */

#include "auto_crtl.h"
#include "planning.h"
#include "RC_channel.h"
#include "GPS.h"
#include "MY_math.h"
#include "manual_ctrl.h"

uint8_t auto_control_mode = auto_mode;
uint8_t control_mode = manual_mode;

_Bool auto_mode_check()
{
	static uint8_t i = 0;
	if(get_channel_pitch_control_in() == 0 && get_channel_yaw_control_in() == 0 && channelPos[AUX2_speed] == HI &&
			gps_data.satellites >= 0 ){//&& lidar_Obstacle_avoidance_detection() == HAL_OK && lidar.health == HAL_OK){
			//gps_data.satellites >= 5

		i++;
		if(i>4){	//4*200ms
			return HAL_OK;
		}
	}else{
		i = 0;
	}

	return HAL_ERROR;
}

/*
 * 航点追踪任务
 */
void tracking_task_ctrl(void)
{
					//纬度           经度
	tracking_planning_crtl(position.latitude,position.longitude);
}
/*
 * 割草任务
 */
uint16_t mower_width = 70;
void mow_task_ctrl(void)
{
	mow_planning_crtl(mower_width);
}

void auto_crtl()
{
	distance_conversion(gps_data.latitude);	//换算当前经纬度1分对应多少厘米

	switch(auto_control_mode)
	{
	case tracking_task:
		control_mode = tracking_task;
		tracking_task_ctrl();
		break;
	case mow_task:
		control_mode = mow_task;
		mow_task_ctrl();
		break;
	default:
		control_mode = auto_mode;
		manual_ctrl();
		break;
	}
}


