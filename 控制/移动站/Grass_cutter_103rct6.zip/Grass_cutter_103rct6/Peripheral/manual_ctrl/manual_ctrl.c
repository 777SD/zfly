/*
 * manual_ctrl.c
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */

#include "manual_ctrl.h"
#include "usart.h"
#include "AS69_T20.h"
#include "RC_channel.h"

uint8_t* BUF_ctrl = 0;

float pitch_value = 0;
float yaw_value = 0;
float thr_value = 0;

void manual_ctrl(void)
{
	static uint8_t speed = 0;
	pitch_value =  (get_channel_pitch_control_in() * 100) + 125;
	yaw_value 	= -(get_channel_yaw_control_in() * 100)   + 125;
	thr_value	=  (get_channel_thr_control_in() * 125)   + 130;
	if(channelPos[AUX2_speed] == CE){
		speed = channelPos[AUX2_speed]-1;
	}else{
		speed = 0;
	}
	BUF_ctrl = AS69_ctrl(channelPos[AUX4_rise_down] ,channelPos[AUX1_engine] ,
							speed ,channelPos[AUX3_constant_speed] ,channelPos[AUX5_stop] ,
										pitch_value ,yaw_value ,thr_value);


	HAL_UART_Transmit(&huart5, (uint8_t *)BUF_ctrl, 19, 10);
}
