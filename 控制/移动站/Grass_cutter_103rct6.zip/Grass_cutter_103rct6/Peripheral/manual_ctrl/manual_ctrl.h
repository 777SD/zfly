/*
 * manual_ctrl.h
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */

#ifndef MANUAL_CTRL_MANUAL_CTRL_H_
#define MANUAL_CTRL_MANUAL_CTRL_H_

#include "main.h"

extern float pitch_value;
extern float yaw_value;
extern float thr_value;

void manual_ctrl(void);

#endif /* MANUAL_CTRL_MANUAL_CTRL_H_ */
