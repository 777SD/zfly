/*
 * RC_channel.h
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */

#ifndef RADIO_RC_CHANNEL_H_
#define RADIO_RC_CHANNEL_H_

#include "main.h"

#define SBUS_DATA_SIZE      25      // 25字节

struct SBUS_t{
    uint16_t ch[16];                // 16个字节数据
};

enum
{
	YAW ,
    PIT ,
    THR ,		//发动机油门
	wu,
    AUX1_engine ,
    AUX2_speed ,
    AUX3_constant_speed ,
    AUX4_rise_down ,
	AUX5_stop,
    CH_NUM
};

typedef enum
{
    LO = 0,
    CE = 2,
    HI = 1,
}CH_Pos;
extern CH_Pos channelPos[CH_NUM];      //辅助通道位置状态
extern float rc_value_unit[3];
extern struct SBUS_t sbus;

extern uint8_t rc_connect_flag;

extern uint8_t sbus_rx_buf[SBUS_DATA_SIZE];    // 接收sbus数据缓冲区

void SBUS_IT_open(void);
void SBUS_UARTE4_Callback(void);

int sbus_data_update(void);
void main_channel_value_update(void);

_Bool get_rc_health(void);
float get_channel_pitch_control_in();  //线性数据
/*遥控数据单位化和加死区后的数据*/
float get_channel_yaw_control_in();    //线性数据
/*遥控数据单位化和加死区后的数据*/
float get_channel_thr_control_in();    //线性数据 -1 to 1

#endif /* RADIO_RC_CHANNEL_H_ */
