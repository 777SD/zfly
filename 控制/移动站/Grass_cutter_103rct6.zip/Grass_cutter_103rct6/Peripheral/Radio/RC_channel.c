/*
 * RC_channel.c
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */
#include "RC_channel.h"
#include "define.h"
#include "main.h"
#include "usart.h"
#include "stdio.h"
#include "gpio.h"
#include "MY_math.h"

_Bool _rc_health;
uint8_t rc_connect_flag = true;

uint8_t sbus_rx_sta = 0;                // sbus 接收状态，0：未完成，1：已完成一帧接收
uint8_t sbus_rx_buf[SBUS_DATA_SIZE];    // 接收sbus数据缓冲区

struct SBUS_t sbus;                     // SBUS 结构体实例化

CH_Pos channelPos[CH_NUM];

void SBUS_IT_open(void)
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart4, (uint8_t *)sbus_rx_buf, SBUS_DATA_SIZE);
}

void SBUS_UARTE4_Callback(void)
{
	if ((sbus_rx_buf[0] == 0x0F)&&sbus_rx_buf[24]==0x00)
	{

		sbus_rx_sta = 1;
	}
	else
	{
		sbus_rx_sta=0;
	}

	if(sbus_rx_sta==1)
	{

		sbus.ch[0] =((sbus_rx_buf[2]<<8)   + (sbus_rx_buf[1])) & 0x07ff;
		sbus.ch[1] =((sbus_rx_buf[3]<<5)   + (sbus_rx_buf[2]>>3)) & 0x07ff;
		sbus.ch[2] =((sbus_rx_buf[5]<<10)  + (sbus_rx_buf[4]<<2) + (sbus_rx_buf[3]>>6)) & 0x07ff;
		sbus.ch[3] =((sbus_rx_buf[6]<<7)   + (sbus_rx_buf[5]>>1)) & 0x07ff;
		sbus.ch[4] =((sbus_rx_buf[7]<<4)   + (sbus_rx_buf[6]>>4)) & 0x07ff;
		sbus.ch[5] =((sbus_rx_buf[9]<<9)   + (sbus_rx_buf[8]<<1) + (sbus_rx_buf[7]>>7)) & 0x07ff;
		sbus.ch[6] =((sbus_rx_buf[10]<<6)  + (sbus_rx_buf[9]>>2)) & 0x07ff;
		sbus.ch[7] =((sbus_rx_buf[11]<<3)  + (sbus_rx_buf[10]>>5)) & 0x07ff;
		sbus.ch[8] =((sbus_rx_buf[13]<<8)  + (sbus_rx_buf[12])) & 0x07ff;

//		 if(sbus_rx_buf[21] != 0) rc_connect_flag = false;		//数据标志位判断是否与遥控器连接
//		 else rc_connect_flag = true;

		sbus_rx_sta = 0;                        // 准备下一次接收
	}
}

/* 遥控数据单位化和去除死区 */
static float data_to_unit_dead(int16_t rawData, int16_t deadband)
{
    float norm = ((float)data_to_deadzone(rawData,0,deadband) / (float)(500-deadband));
    return norm;
}

/* 结构体数组,指示每个通道低中高三种状态 */
CH_Pos channelPos[CH_NUM];      //辅助通道位置状态
int16_t rc_original[CH_NUM] = {0};                  //储存遥控器原始数据
float rc_value_unit[3];                             //遥控器原始数据加死区后单位化
uint16_t rc_sbus_in[18];
int sbus_data_update(void)
{
    for (uint8_t i = 0; i < CH_NUM; ++i) {

        rc_sbus_in[i] = 1000 + (int)((sbus.ch[i]-300)*((float)1000/(1700-300)));	//使数据在1000~2000之间,原始数据在300~1700之间
    }

    return HAL_OK;
}

/*手动遥控控制，遥控器右摇杆控制方向及速度,以下做数据适配
sbus.ch[0] -> AS69data.KY
sbus.ch[1] -> AS69data.KX
*/
void main_channel_value_update(void)
{
    for(uint8_t i=0; i<CH_NUM; ++i)
    {
        if(rc_sbus_in[i] >= 1000)                                           //如果该通道有值,处理通道数据
        {
            if (rc_sbus_in[1]<910||rc_sbus_in[2]<910) {
                _rc_health = false;
            }
            else  _rc_health = true;

            rc_original[i] = 1.1f *(rc_sbus_in[i] - 1500);               //处理成+-500摇杆量,1.21是为遥控器做的适配

            rc_original[i] = (int16_t)limit(rc_original[i],-500,500);   //限制到+—500

        }
        /*接收机掉落仍进不去此判断*/
        else
        {
        	if(i<4){
        		rc_original[i] = 0;                                         //没值全部默认设为中位(1500)//遥控器不开相当于遥控器输入0
        	}else{
        		rc_original[i] = -1000;
        	}

        	rc_original[AUX4_rise_down] = 0;
            _rc_health = false;
        }


        if(rc_original[i] < (-300))
        {
            channelPos[i] = LO;        //处理通道 档位
        }
        else if(rc_original[i] > (300))
        {
            channelPos[i] = HI;         //高档
        }
        else
        {
            channelPos[i] = CE;         //中档
        }
    }

    /*遥控数据单位化和加死区*/
    rc_value_unit[PIT] =  data_to_unit_dead(rc_original[PIT], 40);
    rc_value_unit[YAW] =  data_to_unit_dead(rc_original[YAW], 50);
    rc_value_unit[THR] =  data_to_unit_dead(rc_original[THR], 100);

}

_Bool get_rc_health(void)
{
   return  (_rc_health && rc_connect_flag);
}

/*遥控数据单位化和加死区后的数据*/
float get_channel_pitch_control_in()  //线性数据 -1 to 1
{
    return  rc_value_unit[PIT];
}

/*遥控数据单位化和加死区后的数据*/
float get_channel_yaw_control_in()   //线性数据 -1 to 1
{
    return  rc_value_unit[YAW];
}

/*遥控数据单位化和加死区后的数据*/
float get_channel_thr_control_in()   //线性数据 -1 to 1
{
    return  rc_value_unit[THR];
}



