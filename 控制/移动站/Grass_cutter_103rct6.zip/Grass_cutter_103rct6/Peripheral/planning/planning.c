/*
 * planning.c
 *
 *  Created on: Nov 18, 2023
 *      Author: 28079
 */
#include "stdio.h"
#include "math.h"
#include "main.h"
#include "planning.h"
#include "GPS.h"
#include "AS69_T20.h"
#include "define.h"
#include "RC_channel.h"
#include "usart.h"
#include "MY_math.h"
#include "manual_ctrl.h"
#include "auto_crtl.h"


//经度每隔0.00001度，距离相差约1米
//纬度1分对应1.85km=1851.85cm
//纬度精度到：10e-3,10e-3分=1.85185cm
//经度1分对应111.3km=111319.49cm
//经度精度到：10e-5,10e-5分=1.1131949cm

mow_struct mow[mow_position];
mow_struct mow_p;
position_struct position;


//换算经纬度为cm
void distance_conversion(double latitude)
{
    calculateDistancePerMinute(latitude, &gps_data.latitude_cm, &gps_data.longitude_cm);
}

//计算两经纬度坐标的距离
uint16_t calculate_distance(double latitude_a,double longitude_a,double latitude_b,double longitude_b)
{
	int16_t x = 0;
	int16_t y = 0;
	uint16_t result = 0;

	x = (latitude_a - latitude_b)*gps_data.latitude_cm*100;
	y = (longitude_a - longitude_b)*gps_data.latitude_cm*100;


	result = sqrt(x*x+y*y);
	return result;
}

//计算目标点经纬度与自身现在经纬度的航向角
double Angle_conversion(double target_latitude,double target_longitude,double feedback_latitude,double feedback_longitude)
{
	double lat1_rad, lon1_rad, lat2_rad, lon2_rad, delta_lon, theta;

	 // 将经纬度转换为弧度
	lat1_rad = feedback_latitude * (PI / 180);
	lon1_rad = feedback_longitude * (PI / 180);
	lat2_rad = target_latitude * (PI / 180);
	lon2_rad = target_longitude * (PI / 180);

	// 计算经度差
	delta_lon = lon2_rad - lon1_rad;

	// 计算航向角
	theta = atan2(sin(delta_lon) * cos(lat2_rad), cos(lat1_rad) * sin(lat2_rad) - sin(lat1_rad) * cos(lat2_rad) * cos(delta_lon));

	// 将航向角转换为度数
	double heading_deg = theta * (180 / PI);

	return heading_deg;
}

uint8_t position_flag = HAL_ERROR;
uint8_t* BUF_auto_ctrl = 0;
uint16_t error_range_cm = 25;
uint16_t error_range_ths = 6;
float error_ths = 0;
void tracking_planning_crtl(double target_latitude,double target_longitude)
{
	static uint8_t i = 0;

	gps_data.latitude_cm_error = (target_latitude - gps_data.latitude)*gps_data.latitude_cm*100;
	gps_data.longitude_cm_error = (target_longitude - gps_data.longitude)*gps_data.longitude_cm*100;

	gps_data.feedback_ths = Angle_conversion(target_latitude,target_longitude,gps_data.latitude,gps_data.longitude);
	if(gps_data.feedback_ths < 0){
		gps_data.feedback_ths += 360;
	}

	/*	以gps为圆心，error_range_cm为半径左右误差
	 * 	如果在范围内则停止
	 */
	if(absolute(gps_data.latitude_cm_error) <= error_range_cm && absolute(gps_data.longitude_cm_error) <= error_range_cm ){
		pitch_value = 125;
		yaw_value = 125;

		i++;
		if(i>9){ //i*100ms
			i = 0;
			position_flag = HAL_OK;
		}
		BEEP_toggle;
		LED_toggle;
	}else{
		position_flag = HAL_ERROR;
		BEEP_off;
		LED_off;

		//纠正航向
		error_ths = gps_data.ths - gps_data.feedback_ths;
		//在error_range_ths度允许误差内   [-5,5]或[355,359]/[-359,-355]
		if( absolute(error_ths)< (error_range_ths/2) || absolute(error_ths)> (360 - error_range_ths/2) ||
				absolute(error_ths) == (error_range_ths/2) || absolute(error_ths) == (360 - error_range_ths/2))
		{
			yaw_value = 125;
		}
		//左拐：(5，180]或(-355,-180]
		else if( ( error_ths> (error_range_ths/2) && (error_ths<180 || error_ths==180) ) ||
				(error_ths> ((error_range_ths/2)-360) && (error_ths<-180 || error_ths==-180) ) )
		{
			if(error_ths > 0){
				yaw_value = 105 - error_ths;
			}else{
				yaw_value = 105 - (360 + error_ths);
			}
			yaw_value = limit(yaw_value,0,55);
		}
		//右拐：(-180，-5)或(180，355)
		else if( ( error_ths<-(error_range_ths/2) && error_ths>-180 ) || (error_ths<(360-(error_range_ths/2)) && error_ths>180 ) )
		{
			if(error_ths > 0){
				yaw_value = 150 + (360 - error_ths);
			}else{
				yaw_value = 150 - error_ths;
			}
			yaw_value = limit(yaw_value,200,255);
		}


		//前进,在±15度范围内边走边纠正航向,否则停下纠正航向;(255-125)*0.4cm处开始降低速度
		if( (error_ths>15 && error_ths<345) || (error_ths<-15 && error_ths>-345) ){
			pitch_value = 125;
		}else{
			pitch_value = limit(125 + absolute(gps_data.latitude_cm_error)*0.4, 200,255);
		}
	}

	thr_value	=  (get_channel_thr_control_in() * 125)   + 130;	//发动机油门

	BUF_auto_ctrl = AS69_ctrl(channelPos[AUX4_rise_down] ,channelPos[AUX1_engine] ,
										channelPos[AUX2_speed] ,channelPos[AUX3_constant_speed] ,channelPos[AUX5_stop] ,
										pitch_value ,yaw_value ,thr_value);


	HAL_UART_Transmit(&huart5, (uint8_t *)BUF_auto_ctrl, 19, 10);
}


uint16_t num = 0;
uint8_t flag = mow_position;
uint16_t num_strips = 0;
uint8_t region = 0;
void turn_side_ad_bc(uint16_t mower_width,uint16_t distance_AD)
{
	if(position_flag == HAL_OK){
		if(flag == bc){
			if(num%2 != 0){
				flag = da;
			}else{
				num++;
			}
		}
		else if(num%2 == 0 || flag == da){
			if(num%2 == 0){
				flag = bc;
			}else if(num != 0){
				num++;
			}
		}
	}
	if( flag == da || num == 0){
		// 计算每个条带的起点和终点
		mow_p.insert_latitude[da] = mow[A].latitude[region] + (mow[D].latitude[region] - mow[A].latitude[region]) * (num * mower_width / distance_AD);
		mow_p.insert_longitude[da] = mow[A].longitude[region] + (mow[D].longitude[region] - mow[A].longitude[region]) * (num * mower_width / distance_AD);

		tracking_planning_crtl(mow_p.insert_latitude[da],mow_p.insert_longitude[da]);
	}else if(flag == bc){

		// 计算每个条带的起点和终点
		mow_p.insert_latitude[bc] = mow[B].latitude[region] + (mow[C].latitude[region] - mow[B].latitude[region]) * (num * mower_width / distance_AD);
		mow_p.insert_longitude[bc] = mow[B].longitude[region] + (mow[C].longitude[region] - mow[B].longitude[region]) * (num * mower_width / distance_AD);

		tracking_planning_crtl(mow_p.insert_latitude[bc],mow_p.insert_longitude[bc]);
	}
}

//void turn_side_ab_cd(float mower_width,uint16_t distance_AB)
//{
//	if(position_flag == HAL_OK){
//		if(flag == cd){
//			if(num%2 != 0){
//				flag = ab;
//			}else{
//				num++;
//			}
//		}
//		else if(num%2 == 0 || flag == ab){
//			if(num%2 == 0){
//				flag = cd;
//			}else if(num != 0){
//				num++;
//			}
//		}
//	}
//	if( flag == ab || num == 0){
//		// 计算每个条带的起点和终点
//		mow_p.insert_latitude[ab] = mow[A].latitude + (mow[B].latitude - mow[A].latitude) * (num * mower_width / distance_AB);
//		mow_p.insert_longitude[ab] = mow[A].longitude + (mow[B].longitude - mow[A].longitude) * (num * mower_width / distance_AB);
//		tracking_planning_crtl(mow_p.insert_latitude[ab],mow_p.insert_longitude[ab]);
//	}else if(flag == cd){
//		// 计算每个条带的起点和终点
//		mow_p.insert_latitude[cd] = mow[B].latitude + (mow[C].latitude - mow[D].latitude) * (num * mower_width / distance_AB);
//		mow_p.insert_longitude[cd] = mow[B].longitude + (mow[C].longitude - mow[D].longitude) * (num * mower_width / distance_AB);
//		tracking_planning_crtl(mow_p.insert_latitude[cd],mow_p.insert_longitude[cd]);
//	}
//}

void mow_planning_crtl(uint16_t mower_width_)
{
	static uint8_t last_line = 0;
	static uint8_t change_area = 0;
	uint16_t distance_AB = calculate_distance(mow[A].latitude[region], mow[A].longitude[region],mow[B].latitude[region], mow[B].longitude[region]);
	uint16_t distance_AD = calculate_distance(mow[A].latitude[region], mow[A].longitude[region],mow[D].latitude[region], mow[D].longitude[region]);

	num_strips = (int)(distance_AD / mower_width_);

	//那个边短在哪个边进行转弯，减少转弯次数
//    if(distance_AB>distance_AD){
//    	num_strips = (int)(distance_AD / mower_width);
//    	turn_side_ad_bc(mower_width,distance_AD);
//    }else{
//    	num_strips = (int)(distance_AB / mower_width);
//    	turn_side_ab_cd(mower_width,distance_AB);
//    }

	if(num < num_strips || num == num_strips){
		turn_side_ad_bc(mower_width,distance_AD);
	}else if(num == num+1){
		if(flag == da){
			if(last_line == 0){
				tracking_planning_crtl(mow[D].latitude[region],mow[D].longitude[region]);
				last_line++;
			}else{
				tracking_planning_crtl(mow[C].latitude[region],mow[C].longitude[region]);
				last_line = 0;
				num++;
			}
		}else if(flag == bc){
			if(last_line == 0){
				tracking_planning_crtl(mow[C].latitude[region],mow[C].longitude[region]);
				last_line++;
			}else{
				tracking_planning_crtl(mow[D].latitude[region],mow[D].longitude[region]);
				last_line = 0;
				num++;
			}
		}else{
			last_line = 0;
			num++;
		}
	}else if(change_area == 0){
		tracking_planning_crtl(mow[D].latitude[region],mow[D].longitude[region]);
		change_area = 1;
	}else if(change_area == 1){
		change_area = 0;
		if(region<4){
			region++;
			num = 0;
			num_strips = 0;
			mow_task_ctrl();
		}
	}else{
		num = 0;
		num_strips = 0;
		region = 0;
		auto_control_mode = auto_mode;
	}

}


