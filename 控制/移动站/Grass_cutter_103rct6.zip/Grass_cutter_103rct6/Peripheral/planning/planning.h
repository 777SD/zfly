/*
 * planning.h
 *
 *  Created on: Nov 18, 2023
 *      Author: 28079
 */

#ifndef PLANNING_PLANNING_H_
#define PLANNING_PLANNING_H_

#include "main.h"

#define PI 3.14159265358979323846

enum
{
	A = 0,
	B,
	C,
	D,

	ab = 0,
	bc,
	cd,
	da,

	mow_position,
};

typedef struct
{
	double latitude[4];
	double longitude[4];

	double insert_latitude[4];
	double insert_longitude[4];

}mow_struct;

typedef struct
{
    double latitude;          // 纬度
    char latitudeDirection;   // 纬度方向：N/S
    double longitude;         // 经度
    char longitudeDirection;  // 经度方向：E/W

}position_struct;

extern mow_struct mow[mow_position];
extern position_struct position;;

void distance_conversion(double latitude);
void tracking_planning_crtl(double target_latitude,double target_longitude);
void mow_planning_crtl(uint16_t mower_width_);

#endif /* PLANNING_PLANNING_H_ */
