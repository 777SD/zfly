/*
 * Bluetooth.c
 *
 *  Created on: 2024年1月3日
 *      Author: 28079
 */

#include "Bluetooth.h"
#include "GPS.h"
#include "main.h"
#include "stdio.h"
#include "planning.h"
#include "usart.h"
#include "MyJSON.h"
#include "stdlib.h"
#include "string.h"
#include "auto_crtl.h"
#include "manual_ctrl.h"

uint8_t PC_buf[1] = {0};
uint8_t rx_flag = 0;
uint16_t i = 0;
uint16_t j = 0;
uint16_t ad = 0;

void Bluetooth_IT_Open()
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart2,PC_buf,1);
}

char latitude_buf[20];
char longitude_buf[20];
void Bluetooth_UARTE5_Callback(void)
{
//	static char latitude_buf[20];
//	static char longitude_buf[20];

//	if(PC_buf[0] == 's'){
//		control_mode = tracking_task;
//		rx_flag = 3;
//	}
//
//	if((PC_buf[0] == 't' || rx_flag == 1) && PC_buf[0] != 'n'){
//		if(rx_flag == 1){
//			latitude_buf[i++] = PC_buf[0];
//		}
//		rx_flag = 1;
//	}else if( PC_buf[0] == 'n'|| rx_flag == 2 ){
//		if(rx_flag == 2){
//			longitude_buf[j++] = PC_buf[0];
//		}
//		rx_flag = 2;
//	}else if(rx_flag == 3){
//		position.latitude = atof(latitude_buf);
//		position.longitude = atof(longitude_buf);
//		i = 0;
//		j = 0;
//		rx_flag = 0;
//	}else if(rx_flag == 4){
//		if(PC_buf[0] == 'A'){
//			mow[A].latitude = atof(latitude_buf);
//			mow[A].longitude = atof(longitude_buf);
//		}else if(PC_buf[0] == 'B'){
//			mow[B].latitude = atof(latitude_buf);
//			mow[B].longitude = atof(longitude_buf);
//		}else if(PC_buf[0] == 'C'){
//			mow[C].latitude = atof(latitude_buf);
//			mow[C].longitude = atof(longitude_buf);
//		}else if(PC_buf[0] == 'D'){
//			mow[D].latitude = atof(latitude_buf);
//			mow[D].longitude = atof(longitude_buf);
//		}
//		i = 0;
//		j = 0;
//		rx_flag = 0;
//	}
//
//	if(PC_buf[0] == 'm'){
//		control_mode = mow_task;
//		rx_flag = 4;
//	}

	if(PC_buf[0] == 's'){
		auto_control_mode = tracking_task;
		rx_flag = 3;
	}
	if(PC_buf[0] == 'm'){
		auto_control_mode = mow_task;
		rx_flag = 4;
	}

	if((PC_buf[0] == 0xEE || rx_flag == 1) && PC_buf[0] != 0xEF){
		if(rx_flag == 1){
			latitude_buf[i++] = PC_buf[0];
		}
		rx_flag = 1;
	}else if( (PC_buf[0] == 0xEF && rx_flag == 1)|| rx_flag == 2 ){
		if(rx_flag == 2){
			longitude_buf[j++] = PC_buf[0];
		}
		rx_flag = 2;
	}else if(rx_flag == 3){
		position.latitude = atof(latitude_buf);
		position.longitude = atof(longitude_buf);
		i = 0;
		j = 0;
		rx_flag = 0;
	}else if(rx_flag == 4 || rx_flag == 5 || rx_flag == 6 || rx_flag == 7 || rx_flag == 8){

		if(PC_buf[0] == 'A' || rx_flag == 5){
			switch (PC_buf[0]){
				case '1':	mow[A].latitude[0] = atof(latitude_buf);	mow[A].longitude[0] = atof(longitude_buf);	rx_flag = 10; break;
				case '2':	mow[A].latitude[1] = atof(latitude_buf);	mow[A].longitude[1] = atof(longitude_buf);	rx_flag = 10; break;
				case '3':	mow[A].latitude[2] = atof(latitude_buf);	mow[A].longitude[2] = atof(longitude_buf);	rx_flag = 10; break;
				case '4':	mow[A].latitude[3] = atof(latitude_buf);	mow[A].longitude[3] = atof(longitude_buf);	rx_flag = 10; break;
				default: rx_flag = 5;
			}
		}else if(PC_buf[0] == 'B' || rx_flag == 6){
			switch (PC_buf[0]){
				case '1':	mow[B].latitude[0] = atof(latitude_buf);	mow[B].longitude[0] = atof(longitude_buf);	rx_flag = 10; break;
				case '2':	mow[B].latitude[1] = atof(latitude_buf);	mow[B].longitude[1] = atof(longitude_buf);	rx_flag = 10; break;
				case '3':	mow[B].latitude[2] = atof(latitude_buf);	mow[B].longitude[2] = atof(longitude_buf);	rx_flag = 10; break;
				case '4':	mow[B].latitude[3] = atof(latitude_buf);	mow[B].longitude[3] = atof(longitude_buf);	rx_flag = 10; break;
				default: rx_flag = 6;
			}
		}else if(PC_buf[0] == 'C' || rx_flag == 7){
			switch (PC_buf[0]){
				case '1':	mow[C].latitude[0] = atof(latitude_buf);	mow[C].longitude[0] = atof(longitude_buf);	rx_flag = 10; break;
				case '2':	mow[C].latitude[1] = atof(latitude_buf);	mow[C].longitude[1] = atof(longitude_buf);	rx_flag = 10; break;
				case '3':	mow[C].latitude[2] = atof(latitude_buf);	mow[C].longitude[2] = atof(longitude_buf);	rx_flag = 10; break;
				case '4':	mow[C].latitude[3] = atof(latitude_buf);	mow[C].longitude[3] = atof(longitude_buf);	rx_flag = 10; break;
				default: rx_flag = 7;
			}
		}else if(PC_buf[0] == 'D' || rx_flag == 8){
			switch (PC_buf[0]){
				case '1':	mow[D].latitude[0] = atof(latitude_buf);	mow[D].longitude[0] = atof(longitude_buf);	rx_flag = 10; break;
				case '2':	mow[D].latitude[1] = atof(latitude_buf);	mow[D].longitude[1] = atof(longitude_buf);	rx_flag = 10; break;
				case '3':	mow[D].latitude[2] = atof(latitude_buf);	mow[D].longitude[2] = atof(longitude_buf);	rx_flag = 10; break;
				case '4':	mow[D].latitude[3] = atof(latitude_buf);	mow[D].longitude[3] = atof(longitude_buf);	rx_flag = 10; break;
				default: rx_flag = 8;
			}
		}

		if(rx_flag == 10){
			i = 0;
			j = 0;
			rx_flag = 0;
		}

	}


}

void Send_real_time_data(void)
{
//	char* data_string = bluetooth_to_Json();
//	HAL_UART_Transmit(&huart5, (uint8_t *)data_string, strlen(data_string), 10);	//数据回传至pc

//	printf("ths:%d\r\n",gps_data.ths);
//	printf("feedback_ths:%d\r\n",gps_data.feedback_ths);
//	printf("latitude*1000:%f\r\n",gps_data.latitude*1000);
//	printf("longitude*1000:%f\r\n",gps_data.longitude*1000);
//	printf("latitude_cm_error:%d\r\n",gps_data.latitude_cm_error);
//	printf("longitude_cm_error:%d\r\n",gps_data.longitude_cm_error);
//	printf("satellites:%d\r\n",gps_data.satellites);
//	printf("control_mode:%d\r\n",control_mode);
//	printf("PIT:%d\r\n",(int)pitch_value);
//	printf("YAW:%d\r\n",(int)yaw_value);
//	printf("THR:%d\r\n",(int)thr_value);


//	printf("\n");
//
//	printf("cardatashow.t11.txt=\"%d\"\xff\xff\xff",gps_data.ths);
//	printf("cardatashow.t12.txt=\"%f\"\xff\xff\xff",gps_data.longitude*1000);
//	printf("cardatashow.t13.txt=\"%f\"\xff\xff\xff",gps_data.latitude*1000);
//	switch(control_mode){
//		case manual_mode:		printf("cardatashow.t14.txt=\"manual_mode\"\xff\xff\xff");		break;
//		case auto_mode:			printf("cardatashow.t14.txt=\"auto_mode\"\xff\xff\xff");		break;
//		case tracking_task:		printf("cardatashow.t14.txt=\"tracking_task\"\xff\xff\xff");	break;
//		case mow_task:			printf("cardatashow.t14.txt=\"mow_task\"\xff\xff\xff");		break;
//	}
//	printf("cardatashow.t23.txt=\"%d\"\xff\xff\xff",gps_data.satellites);
//	printf("cardatashow.t18.txt=\"%d\"\xff\xff\xff",gps_data.longitude_cm_error);
//	printf("cardatashow.t19.txt=\"%d\"\xff\xff\xff",gps_data.latitude_cm_error);
//	printf("cardatashow.t20.txt=\"%d\"\xff\xff\xff",gps_data.feedback_ths);




	printf("\xE1%d",gps_data.ths);
	printf("\xE2%f",gps_data.longitude*1000);
	printf("\xE3%f",gps_data.latitude*1000);
	switch(control_mode){
		case manual_mode:		printf("\xE4\x02");		break;
		case auto_mode:			printf("\xE4\x03");		break;
		case tracking_task:		printf("\xE4\x00");		break;
		case mow_task:			printf("\xE4\x01");		break;
	}
	printf("\xE5%d",gps_data.satellites);
	printf("\xE6%d",gps_data.longitude_cm_error);
	printf("\xE7%d",gps_data.latitude_cm_error);
	printf("\xE8%d\xE9",gps_data.feedback_ths);

	printf("\n");

}
