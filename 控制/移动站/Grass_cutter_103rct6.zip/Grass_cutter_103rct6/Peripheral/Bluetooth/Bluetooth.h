/*
 * Bluetooth.h
 *
 *  Created on: 2024年1月3日
 *      Author: 28079
 */

#ifndef BLUETOOTH_BLUETOOTH_H_
#define BLUETOOTH_BLUETOOTH_H_


void Bluetooth_IT_Open();
void Bluetooth_UARTE5_Callback(void);
void Send_real_time_data(void);

#endif /* BLUETOOTH_BLUETOOTH_H_ */
