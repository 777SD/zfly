/*
 * CRC16.h
 *
 *  Created on: Nov 22, 2023
 *      Author: 28079
 */

#ifndef COMMUNICATE_CRC16_H_
#define COMMUNICATE_CRC16_H_

#include "main.h"

uint16_t GetCRC16(uint8_t *ptr,  uint8_t len);

#endif /* COMMUNICATE_CRC16_H_ */
