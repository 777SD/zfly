/*
 * AS69_T20.h
 *
 *  Created on: Nov 17, 2023
 *      Author: 28079
 */

#ifndef COMMUNICATE_AS69_T20_H_
#define COMMUNICATE_AS69_T20_H_

#include "main.h"

typedef struct
{
	uint8_t IO;		//功能
	uint8_t KY;
	uint8_t KX;		//KY和KX组合完成行走的方向和速度控制
	uint8_t YW1;	//发动机油门舵机控制字
	uint8_t YW2;	//预留控制字

	uint8_t CRC_high;
	uint8_t CRC_low;
}AS69_buf_data;

//行进方向							数值范围
//正前方行进				KY>143   105<KX<=150
//右前方差速转弯行进			KY>143   150<KX<=255
//左前方差速转弯行进			KY>143  	 KX<105
//右掉头				113<KY<=143  150<KX<=255
//停止				113<KY<=143  105<KX<=150
//左掉头				113<KY<=143		 KX<105
//正后方行进				KY<=113  105<KX<=150
//右后方差速转弯行进			KY<=113  150<KX<=255
//左后方差速转弯行进			KY<=113  	 KX<105

enum
{
	stop,						//急停
	low_speed,					//低速
	high_speed,					//高速
	constant_speed,				//定速巡航
	rise,						//高度升
	down,						//高度降
	start_the_engine,			//启动发动机
	shut_down_the_engine,		//关闭发动机

	forward,					//前进
	retreat,					//后退
	left,						//向右
	right,						//向左

	auto_ctrl,
	manual,

	mode_choose
};

void AS69_IT_Open();
void AS69_usart2_callback();
void AS69_connect_tx(void);

void EMERGENCY_STOP(void);
uint8_t* AS69_ctrl(uint8_t height,uint8_t engine,uint8_t speed_mode,uint8_t constant_speed,uint8_t stop,uint8_t KY,uint8_t KX,uint8_t throttle);

#endif /* COMMUNICATE_AS69_T20_H_ */
