/*
 * AS69_T20.c
 *
 *  Created on: Nov 17, 2023
 *      Author: 28079
 */

#include "AS69_T20.h"
#include "usart.h"
#include "define.h"
#include "CRC16.h"
#include "RC_channel.h"

uint8_t AS69_rx_data[1] = {0};

void AS69_IT_Open()
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart5, (uint8_t *)AS69_rx_data, 1);
}

void AS69_usart2_callback()
{
//	static uint8_t rx_flag = 0;
//	static uint8_t RX_data[30] = {0};
//	static uint8_t rx_len = 0;


}

void AS69_connect_tx(void)
{
	static uint8_t connect_buf[27] = {0x02,0x10,0x00,0x00,0x00,0x05,0x0A,
									0x00,0x00,0x00,0x7E,0x00,0x7D,0x00,
									0x05,0x00,0x01,0xD2,0xC4,0x02,0x03,
									0x00,0x00,0x00,0x01,0x84,0x39};
	HAL_UART_Transmit(&huart5, (const uint8_t *)connect_buf, 27, 10);
}


AS69_buf_data AS69data;
uint8_t AS69_buf[19] = {0x02,0x10,0x00,0x00,0x00,0x05,0x0A,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uint16_t crc_value;

//急停
void EMERGENCY_STOP(void)
{
	AS69data.IO = 0x20;
	crc_value = GetCRC16((uint8_t *)AS69_buf,17);
	AS69data.CRC_low = crc_value;
	AS69data.CRC_high = (crc_value>>8)|0x0000;


	AS69_buf[17] = AS69data.CRC_low;
	AS69_buf[18] = AS69data.CRC_high;
	HAL_UART_Transmit(&huart5, (const uint8_t *)AS69_buf, 19, 10);
}

uint8_t* AS69_ctrl(uint8_t height,uint8_t engine,uint8_t speed_mode,uint8_t constant_speed,uint8_t stop,
					uint8_t KY,uint8_t KX,uint8_t throttle)
{
	uint8_t high_low = 0;
	uint8_t high_high = 0;
	if(height == CE){
		high_low = 0;
		high_high = 0;
	}else if(height == LO){
		high_low = 1;
		high_high = 0;
	}else{
		high_low = 0;
		high_high = 1;
	}

	AS69data.IO = (stop<<6) | (constant_speed<<4) | (speed_mode<<3) | (engine<<2) | (high_high<<1) | high_low | 0x00;
	AS69data.KY = KY;
	AS69data.KX = KX;
	AS69data.YW1 = throttle;
//	AS69data.YW2 = ;


	AS69_buf[8] = AS69data.IO;
	AS69_buf[10] = AS69data.KY;
	AS69_buf[12] = AS69data.KX;
	AS69_buf[14] = AS69data.YW1;
	AS69_buf[16] = 0x01;//AS69data.YW2;

	crc_value = GetCRC16((uint8_t *)AS69_buf,17);
	AS69data.CRC_low = crc_value;
	AS69data.CRC_high = (crc_value>>8)|0x0000;


	AS69_buf[17] = AS69data.CRC_low;
	AS69_buf[18] = AS69data.CRC_high;


	return AS69_buf;
}


