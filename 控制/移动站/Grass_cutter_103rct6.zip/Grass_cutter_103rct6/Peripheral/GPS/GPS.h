/*
 * GPS.h
 *
 *  Created on: Nov 17, 2023
 *      Author: 28079
 */

#ifndef GPS_GPS_H_
#define GPS_GPS_H_

#include "main.h"
#include "define.h"

#define GPS_buff 1024
//定义数组长度
typedef struct{
	int year;
	int month;
	int day;
	int hour;
	int minute;
	int second;
}date_time;

typedef struct{
	 date_time D;//时间
	 char status;  		//接收状态
	 double	latitude;   //纬度
	 double longitude;  //经度
	 char NS;           //南北极
	 char EW;           //东西
	 double speed;      //速度
	 double course;     // 航向
	 int16_t ths;		//和芯星通双天线航向
	 int satellites;    // 卫星数

	 int16_t longitude_cm_error;
	 int16_t latitude_cm_error;
	 int16_t feedback_ths;
	 double latitude_cm;
	 double longitude_cm;
}GPSData;

extern GPSData gps_data;

void GPS_IT_open(void);
void GPS_usart1_Callback();
void process_gps_data(uint8_t *rxData, size_t len, GPSData *data);
int get_field_value(char *buf, int field) ;
void gps_parse(char *line,GPSData *GPS);

#endif /* GPS_GPS_H_ */
