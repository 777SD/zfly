/*
 * LED.h
 *
 *  Created on: Jun 22, 2024
 *      Author: SGM
 */

#ifndef LED_LED_H_
#define LED_LED_H_

void LED_Init(void);
void LED_order(void);
void LED_run(void);
void LED_3T(void);
void LED_32T(void);
void LED_4T(void);
#endif /* LED_LED_H_ */
