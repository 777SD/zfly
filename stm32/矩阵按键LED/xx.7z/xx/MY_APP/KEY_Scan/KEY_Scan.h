/*
 * KEY_Scan.h
 *
 *  Created on: Jun 22, 2024
 *      Author: SGM
 */

#ifndef KEY_SCAN_KEY_SCAN_H_
#define KEY_SCAN_KEY_SCAN_H_

#define KEY_Touch	1
#define KEY_NOTouch	0

extern uint8_t Keycoord[4][4];

void Key_Init();
void Key_Scan();

#endif /* KEY_SCAN_KEY_SCAN_H_ */
