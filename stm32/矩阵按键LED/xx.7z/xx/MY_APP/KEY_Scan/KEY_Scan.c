/*
 * KEY_Scan.c
 *
 *  Created on: Jun 22, 2024
 *      Author: SGM
 */
#include "main.h"
#include "gpio.h"
#include "KEY_Scan.h"

uint8_t Keycoord[4][4]={0};
uint8_t Keyh = 0, Keyl = 0, Keyf=0;


void Key_Init()
{
	HAL_GPIO_WritePin(KEY1_GPIO_Port, KEY1_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(KEY2_GPIO_Port, KEY2_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(KEY3_GPIO_Port, KEY3_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(KEY4_GPIO_Port, KEY4_Pin, GPIO_PIN_RESET);

}

void KEYl()
{
	if(HAL_GPIO_ReadPin(KEYL1_GPIO_Port,KEYL1_Pin) == 1 )
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(KEYL1_GPIO_Port,KEYL1_Pin) == 1);
		Keyl = 0;
		Keyf = 1;
	}

	if(HAL_GPIO_ReadPin(KEYL2_GPIO_Port,KEYL2_Pin) == 1 )
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(KEYL2_GPIO_Port,KEYL2_Pin) == 1);
		Keyl = 1;
		Keyf = 1;
	}

	if(HAL_GPIO_ReadPin(KEYL3_GPIO_Port,KEYL3_Pin) == 1 )
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(KEYL3_GPIO_Port,KEYL3_Pin) == 1);
		Keyl = 2;
		Keyf = 1;
	}

	if(HAL_GPIO_ReadPin(KEYL4_GPIO_Port,KEYL4_Pin) == 1 )
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(KEYL4_GPIO_Port,KEYL4_Pin) == 1);
		Keyl = 3;
		Keyf = 1;
	}

}


void Key_Scan()
{
	//扫描第一层
	HAL_GPIO_TogglePin(KEY1_GPIO_Port, KEY1_Pin);
	KEYl();
	if(Keyf == 1)
	{
		Keycoord[0][Keyl]=1;
		Keyf=0;
	}



	//扫描第二层
	HAL_GPIO_TogglePin(KEY1_GPIO_Port, KEY1_Pin);
	HAL_GPIO_TogglePin(KEY2_GPIO_Port, KEY2_Pin);
	KEYl();
	if(Keyf == 1)
	{
		Keycoord[1][Keyl]=1;
		Keyf=0;
	}


	//扫描第三层
	HAL_GPIO_TogglePin(KEY2_GPIO_Port, KEY2_Pin);
	HAL_GPIO_TogglePin(KEY3_GPIO_Port, KEY3_Pin);
	KEYl();
	if(Keyf == 1)
	{
		Keycoord[2][Keyl]=1;
		Keyf=0;
	}

	//扫描第四层
	HAL_GPIO_TogglePin(KEY3_GPIO_Port, KEY3_Pin);
	HAL_GPIO_TogglePin(KEY4_GPIO_Port, KEY4_Pin);
	KEYl();
	if(Keyf == 1)
	{
		Keycoord[3][Keyl]=1;
		Keyf=0;
	}


	HAL_GPIO_TogglePin(KEY4_GPIO_Port, KEY4_Pin);
}




