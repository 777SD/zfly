#ifndef __HCSR04_H
#define __HCSR04_H
#include "sys.h"
#include "delay.h"

#define TRIG  PAout(1) 
//#define ECHO  PAin(0)

void HCSR04_TRIG_Send(void);
void HCSR04_TRIG_Init(void);
float Get_Distance(void);

extern float distance;

#endif



