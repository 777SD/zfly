#include "sys.h"	
uint8_t full=0;
void InfrarePSwitch_Init(void)
{
 	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE); 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;				 
	GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IN; 		
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 
	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_10);
}

void InfrarePSwitch_Check(void)
{
	if(sign == 0)
	{   
		  OLED_ShowString(2,2,"FULL");
		  full=8;
		  Buzzer_ON();
		  Delay_ms(30);
		  Buzzer_OFF();
	}
	else
	{
		full=0;
		Buzzer_OFF();
	}
	
}
