#ifndef __InfrarePSwitch_H
#define __InfrarePSwitch_H	 
#include "sys.h"
 
#define  sign  GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_10)	 

void InfrarePSwitch_Init(void);
void InfrarePSwitch_Check(void);
	 
#endif

