#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h" 
 

/*����ķ�ʽ��ͨ��ֱ�Ӳ����⺯����ʽ��ȡIO*/
#define SW0 		GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11) //PE4
#define SW1 		GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)	//PE3 


/*���淽ʽ��ͨ��λ��������ʽ��ȡIO*/
#define KEY0 		PFin(6)   
#define KEY1 		PFin(5)	
#define KEY2 		PFin(8)		
#define KEY3 		PFin(10)		

extern u8 key_jishu;
extern u8 key0_status;
extern u8 key1_status;
extern u8 key2_status;
extern u8 key3_status;

extern u8 key0_last_status;
extern u8 key1_last_status;
extern u8 key2_last_status;
extern u8 key3_last_status;

extern u8 key0_flag;
extern u8 key1_flag;
extern u8 key2_flag;
extern u8 key3_flag;


void KEY_Init(void);
void Switch_Init(void);
uint8_t Key_GetNum(void);
#endif
