#ifndef __SERVO_H
#define __SERVO_H
#include "sys.h"
#include "delay.h"
void TIM9_PWM_Init(u32 arr,u32 psc);//
void TIM10_PWM_Init(u32 arr, u32 psc);//
void TIM13_14_PWM_Init(u32 arr, u32 psc);
u16 servo_set(u16 zhi);
#endif

