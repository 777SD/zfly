#ifndef __Motorstep_H
#define __Motorstep_H 
#include "sys.h"
 
	void step_Init(void);
	 
#endif
