#ifndef __PID_H
#define __PID_H
#include "sys.h"


extern float pid_motor_out[4];

void pid_motor(void);
float pid_yaw(float cur,float tar );
float pid_xunxian(float cur,float tar );

#endif

