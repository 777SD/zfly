#include "sys.h"

float speed_amplitude = 100;
float tar_Xspeed, tar_Yspeed;
float Axle_spacing = 0.095f, Wheel_spacing = 0.086f;
float MOTORA_Target, MOTORB_Target, MOTORC_Target, MOTORD_Target;
float speed_yaw, tar_yaw;

//�����˶�ѧ���
void motion_analyse(float Vx, float Vy, float Vz)
{
    motor_target_speed[0] = (Vy + Vx - Vz * (Axle_spacing + Wheel_spacing));
    motor_target_speed[1] = (Vy - Vx + Vz * (Axle_spacing + Wheel_spacing));
    motor_target_speed[2] = (Vy - Vx - Vz * (Axle_spacing + Wheel_spacing));
    motor_target_speed[3] = (Vy + Vx + Vz * (Axle_spacing + Wheel_spacing));

    // Wheel (motor) target speed limit //����(���)Ŀ���ٶ��޷�
    motor_target_speed[0] = target_limit_float(motor_target_speed[0], -speed_amplitude, speed_amplitude);
    motor_target_speed[1] = target_limit_float(motor_target_speed[1], -speed_amplitude, speed_amplitude);
    motor_target_speed[2] = target_limit_float(motor_target_speed[2], -speed_amplitude, speed_amplitude);
    motor_target_speed[3] = target_limit_float(motor_target_speed[3], -speed_amplitude, speed_amplitude);
}

u8 PT_sun = 3; //��λ����
u8 PT_now;     //Ŀǰ�������еĵ�λ
u8 PT_pass;    //��λͨ����־λ
u16 PT_speed = 50;
int PT_coord[3][2] = //װ�ص�λxy����
    {
        {50, 100},
        {100, 50},
        {0, 0},
};

void Go_PT(void)
{

    if (PT_pass && jishu1 >= 100)
    {
        jishu1_flag = 0;
        jishu1 = 0;

        PT_pass = 0;
        PT_now++;
    }

    if (PT_now < PT_sun && PT_pass == 0)
    {
        //����xy��Ŀ���ٶ�
        tar_Xspeed = (PT_coord[PT_now][0] - X_distance) / (myabs(PT_coord[PT_now][0] - X_distance) + myabs(PT_coord[PT_now][1] - Y_distance)) * PT_speed;
        tar_Yspeed = (PT_coord[PT_now][1] - Y_distance) / (myabs(PT_coord[PT_now][0] - X_distance) + myabs(PT_coord[PT_now][1] - Y_distance)) * PT_speed;
    }

    if (myabs((PT_coord[PT_now][0] - X_distance)) < 1 && myabs((PT_coord[PT_now][1] - Y_distance)) < 1)
    {
        PT_pass = 1;
        jishu1_flag = 1;
        tar_Xspeed = 0;
        tar_Yspeed = 0;
    }
}
