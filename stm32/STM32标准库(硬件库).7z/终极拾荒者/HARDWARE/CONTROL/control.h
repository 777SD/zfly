#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"

void Go_PT(void);
void motion_analyse(float Vx,float Vy,float Vz);

extern float tar_Xspeed,tar_Yspeed;
extern float speed_yaw,tar_yaw;
extern float speed_amplitude;
extern float MOTORA_Target,MOTORB_Target,MOTORC_Target,MOTORD_Target;;


#endif


