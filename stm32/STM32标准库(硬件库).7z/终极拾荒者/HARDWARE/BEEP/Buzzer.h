#ifndef BUZZER_H
#define BUZZER_H
void Buzzer_Init(void);
void Buzzer_ON(void);
void Buzzer_OFF(void);


#endif
