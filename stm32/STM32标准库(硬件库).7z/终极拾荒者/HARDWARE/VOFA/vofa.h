#ifndef __VOFA_H
#define __VOFA_H
#include "sys.h"

#define COUNT_TX 36

extern u8 tail[4];
extern float Vofa_txdata[COUNT_TX];

extern float vofa_dat[4];
extern float vofa_shu1;
extern float vofa_shu2;
extern float vofa_show1;
extern float vofa_show2;
extern float vofa_ch0;

void Send_data(USART_TypeDef * USARTx,u8 *s,u32 len);
void vofa_upload(void);	 	
void vofa_download(void);
	
#endif
