#include "sys.h"


float  vofa_ch0;
float  vofa_shu1;
float  vofa_shu2;
float  vofa_show1;
float  vofa_show2;
float  vofa_dat[4];    
float  Vofa_txdata[COUNT_TX];
u8 tail[4] = {0x00, 0x00, 0x80, 0x7f};

void vofa_upload(void)
{
    Vofa_txdata[1] = (float)temp / 100;
    Vofa_txdata[2] = (float)yaw;
    Vofa_txdata[3] = (float)rev_finish_flag;
    Vofa_txdata[4] = vofa_show1;
    Vofa_txdata[5] = vofa_show2;
    Vofa_txdata[6] = Encode_zhi[0];
    Vofa_txdata[7] = motor_target_speed[0];
    Vofa_txdata[8] = pid_motor_out[0];
    Vofa_txdata[9] = tar_yaw;
    Vofa_txdata[10] = yaw;

    Send_data(USART3, (u8 *)Vofa_txdata, 4 * COUNT_TX);
    Send_data(USART3, tail, 4);

}

void vofa_download(void)
{
    if (rev_finish_flag == 1)
    {
        float *vofa_dat = (float *)(vofarx_data);
        vofa_ch0 = vofa_dat[0];
        vofa_shu1 = vofa_dat[1];
        vofa_shu2 = vofa_dat[2];
        rev_finish_flag = 0;
        vofa_i = 0; //���ɺ��ԣ���ֹ���ݴ�λ
    }

    switch ((u8)vofa_ch0)
    {
    case 1:
        vofa_show1 = vofa_shu1;
        vofa_show2 = vofa_shu2;
        break;
    case 2:
        tar_yaw = vofa_shu1;
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        break;
    case 6:
        break;
    }
}



void Send_data(USART_TypeDef *USARTx, u8 *s, u32 len)
{
    while (len--)
    {
        while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
        USART_SendData(USARTx, *s);
        s++;
    }

}
