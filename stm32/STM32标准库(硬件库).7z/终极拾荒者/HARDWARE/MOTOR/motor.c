#include "sys.h"

/*
                              ��ͷ
���0��MotorD+TIMch1+Encode2   //   ���1��MotorC+TIMch4+Encode5
���2��MotorB+TIMch2+Encode4   //   ���3��MotorA+TIMch3+Encode3
                              ��β

                                                            y��
                                                            ^
                                                            |
                                                            |
                                                            |
                                                            |
                                                            |
                                                            ------------------>x��
*/

float motor_target_speed[4];
//------------------------------------------------------------------------------------------------------------------

// short temp;                   //�¶�
// float pitch,roll,yaw;         //ŷ����
// short aacx,aacy,aacz;     //���ٶȴ�����ԭʼ����
// short gyrox,gyroy,gyroz;  //������ԭʼ����

void Motor_PWM_Init(u16 arr, u16 psc)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);  //
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE); //ʹ��GPIO����ʱ��ʹ��

    GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource8, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource9, GPIO_AF_TIM8);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9; // GPIOC6.7.8.9
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;                                     //�������
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;                                   //���츴��
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;                               //�ٶ�100MHZ
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;                                     //����
    GPIO_Init(GPIOC, &GPIO_InitStructure);                                           //��ʼ��

    TIM_TimeBaseStructure.TIM_Period = arr;                     //��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ
    TIM_TimeBaseStructure.TIM_Prescaler = psc;                  //����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ  ����Ƶ
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //����ʱ�ӷָ�
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; // TIM���ϼ���ģʽ
    TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);             //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;               //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ1
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;   //�Ƚ����ʹ��
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //�Ƚ����ʹ��
    TIM_OCInitStructure.TIM_Pulse = 0;                              //���ô�װ�벶��ȽϼĴ���������ֵ
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;       //�������:TIM����Ƚϼ��Ը�
    TIM_OC1Init(TIM8, &TIM_OCInitStructure);                        //����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIMx
    TIM_OC2Init(TIM8, &TIM_OCInitStructure);                        //����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIMx
    TIM_OC3Init(TIM8, &TIM_OCInitStructure);                        //����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIMx
    TIM_OC4Init(TIM8, &TIM_OCInitStructure);                        //����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIMx

    TIM_CtrlPWMOutputs(TIM8, ENABLE); // MOE �����ʹ��

    TIM_OC1PreloadConfig(TIM8, TIM_OCPreload_Enable); // CH1Ԥװ��ʹ��
    TIM_OC2PreloadConfig(TIM8, TIM_OCPreload_Enable); // CH1Ԥװ��ʹ��
    TIM_OC3PreloadConfig(TIM8, TIM_OCPreload_Enable); // CH1Ԥװ��ʹ��
    TIM_OC4PreloadConfig(TIM8, TIM_OCPreload_Enable); // CH4Ԥװ��ʹ��

    TIM_ARRPreloadConfig(TIM8, ENABLE); //ʹ��TIMx��ARR�ϵ�Ԥװ�ؼĴ���

    TIM_Cmd(TIM8, ENABLE); //ʹ��TIM
}

void MOTOR_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;      //��ͨ���ģʽ
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;     //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; // 100MHz
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;     //����
    GPIO_Init(GPIOA, &GPIO_InitStructure);             //��ʼ��GPIO

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;      //��ͨ���ģʽ
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;     //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; // 100MHz
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;     //����
    GPIO_Init(GPIOE, &GPIO_InitStructure);             //��ʼ��GPIO

    GPIO_ResetBits(GPIOA, GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);
    GPIO_ResetBits(GPIOE, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
}

void SetMotor_PWM(float motor_a, float motor_b, float motor_c, float motor_d)
{
    if (motor_a > 0)
    {
        motorD1 = 1;
        motorD2 = 0;
        TIM_SetCompare1(TIM8, motor_a);
    }
    if (motor_a < 0)
    {
        motorD1 = 0;
        motorD2 = 1;
        TIM_SetCompare1(TIM8, -motor_a);
    }
    if (motor_a == 0)
    {
        motorD1 = 0;
        motorD2 = 0;
        TIM_SetCompare1(TIM8, motor_a);
    }
    //---------------------------------------------------
    if (motor_b > 0)
    {
        motorC1 = 1;
        motorC2 = 0;
        TIM_SetCompare4(TIM8, motor_b);
    }
    if (motor_b < 0)
    {
        motorC1 = 0;
        motorC2 = 1;
        TIM_SetCompare4(TIM8, -motor_b);
    }
    if (motor_b == 0)
    {
        motorC1 = 0;
        motorC2 = 0;
        TIM_SetCompare4(TIM8, motor_b);
    }
    ////--------------------------------------------------
    if (motor_c > 0)
    {
        motorB1 = 1;
        motorB2 = 0;
        TIM_SetCompare2(TIM8, motor_c);
    }
    else if (motor_c < 0)
    {
        motorB1 = 0;
        motorB2 = 1;
        TIM_SetCompare2(TIM8, -motor_c);
    }
    else if (motor_c == 0)
    {
        motorB1 = 0;
        motorB2 = 0;
        TIM_SetCompare2(TIM8, motor_c);
    }
    ////------------------------------------------------------
    if (motor_d > 0)
    {
        motorA1 = 1;
        motorA2 = 0;
        TIM_SetCompare3(TIM8, motor_d);
    }
    else if (motor_d < 0)
    {
        motorA1 = 0;
        motorA2 = 1;
        TIM_SetCompare3(TIM8, -motor_d);
    }
    else if (motor_d == 0)
    {
        motorA1 = 0;
        motorA2 = 0;
        TIM_SetCompare3(TIM8, motor_d);
    }
}

void Encoder_Init_TIM2(void)
{

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);  //ʹ�ܶ�ʱ��2��ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); //ʹ��PA�˿�ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); //ʹ��PB�˿�ʱ��

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;         // GPIOA15
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;       //
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;     //
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; //
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;       //
    GPIO_Init(GPIOA, &GPIO_InitStructure);             //�����趨������ʼ��GPIOA

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;          // GPIOB3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;       //
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;     //
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; //
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;       //
    GPIO_Init(GPIOB, &GPIO_InitStructure);             //�����趨������ʼ��GPIOA

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource15, GPIO_AF_TIM2); // GPIOA15���ó�TIM2_CH1
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource3, GPIO_AF_TIM2);  // GPIOB3 ���ó�TIM2_CH2

    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);             //
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;                  // Ԥ��Ƶ��
    TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD;      //�趨�������Զ���װֵ
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //ѡ��ʱ�ӷ�Ƶ������Ƶ
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; ////TIM���ϼ���
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
//#define ENCODER_TIM_PERIOD (u16)(65535)
    TIM_EncoderInterfaceConfig(TIM2, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising); //ʹ�ñ�����ģʽ3

    TIM_ICStructInit(&TIM_ICInitStructure);
    TIM_ICInitStructure.TIM_ICFilter = 0;
    TIM_ICInit(TIM2, &TIM_ICInitStructure);

    TIM_ClearFlag(TIM2, TIM_FLAG_Update); //���TIM�ĸ��±�־λ
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    TIM_SetCounter(TIM2, 0);
    TIM_Cmd(TIM2, ENABLE);
}
void Encoder_Init_TIM3(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);  //ʹ�ܶ�ʱ��4��ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); //ʹ��PB�˿�ʱ��

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7; // GPIOA6.7
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;           //
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;         //
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;     //
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;           //
    GPIO_Init(GPIOA, &GPIO_InitStructure);                 //��ʼ��

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_TIM3); // GPIOB6.7 ���ó�TIM3_CH1
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_TIM3); // GPIOB6.7 ���ó�TIM3_CH2

    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;                  // Ԥ��Ƶ��
    TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD;      //�趨�������Զ���װֵ65535
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //ѡ��ʱ�ӷ�Ƶ������Ƶ
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; ////TIM���ϼ���
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising); //ʹ�ñ�����ģʽ3
    TIM_ICStructInit(&TIM_ICInitStructure);
    TIM_ICInitStructure.TIM_ICFilter = 0;
    TIM_ICInit(TIM3, &TIM_ICInitStructure);

    TIM_ClearFlag(TIM3, TIM_FLAG_Update); //���TIM�ĸ��±�־λ
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    TIM_SetCounter(TIM3, 0);
    TIM_Cmd(TIM3, ENABLE);
}

void Encoder_Init_TIM4(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);  //ʹ�ܶ�ʱ��4��ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); //ʹ��PB�˿�ʱ��

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7; // GPIOB6.7
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;           //
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;         //
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;     //
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;           //
    GPIO_Init(GPIOB, &GPIO_InitStructure);                 //��ʼ��

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_TIM4); // GPIOB6.7 ���ó�TIM4_CH1
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_TIM4); // GPIOB6.7 ���ó�TIM4_CH2

    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;                  // Ԥ��Ƶ��
    TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD;      //�趨�������Զ���װֵ65535
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //ѡ��ʱ�ӷ�Ƶ������Ƶ
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; ////TIM���ϼ���
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising); //ʹ�ñ�����ģʽ3
    TIM_ICStructInit(&TIM_ICInitStructure);
    TIM_ICInitStructure.TIM_ICFilter = 0;
    TIM_ICInit(TIM4, &TIM_ICInitStructure);

    TIM_ClearFlag(TIM4, TIM_FLAG_Update); //���TIM�ĸ��±�־λ
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

    TIM_SetCounter(TIM4, 0);
    TIM_Cmd(TIM4, ENABLE);
}

void Encoder_Init_TIM5(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);  //ʹ�ܶ�ʱ��4��ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); //ʹ��PB�˿�ʱ��

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1; // GPIOA.0.1
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;           //
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;         //
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;     //
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;           //
    GPIO_Init(GPIOA, &GPIO_InitStructure);                 //��ʼ��

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_TIM5); // GPIOB6.7 ���ó�TIM4_CH1
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_TIM5); // GPIOB6.7 ���ó�TIM4_CH2

    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;                  // Ԥ��Ƶ��
    TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD;      //�趨�������Զ���װֵ65535
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //ѡ��ʱ�ӷ�Ƶ������Ƶ
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; ////TIM���ϼ���
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    TIM_EncoderInterfaceConfig(TIM5, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising); //ʹ�ñ�����ģʽ3
    TIM_ICStructInit(&TIM_ICInitStructure);
    TIM_ICInitStructure.TIM_ICFilter = 0;
    TIM_ICInit(TIM5, &TIM_ICInitStructure);

    TIM_ClearFlag(TIM5, TIM_FLAG_Update); //���TIM�ĸ��±�־λ
    TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);

    TIM_SetCounter(TIM5, 0);
    TIM_Cmd(TIM5, ENABLE);
}

int Read_Encoder(u8 TIMX)
{
    int Encoder_TIM;
    switch (TIMX)
    {
    case 2:
        Encoder_TIM = (short)TIM2->CNT;
        TIM2->CNT = 0;
        break;
    case 3:
        Encoder_TIM = (short)TIM3->CNT;
        TIM3->CNT = 0;
        break;
    case 4:
        Encoder_TIM = (short)TIM4->CNT;
        TIM4->CNT = 0;
        break;
    case 5:
        Encoder_TIM = (short)TIM5->CNT;
        TIM5->CNT = 0;
        break;
    default:
        Encoder_TIM = 0;
    }
    return Encoder_TIM;
}

//����������------------------------------------------------------------------------------------------------------------------------------------

float wheel_s[4];                                                   //�ĸ����ӱ��������ֽ��
float average_distance, X_Encode, Y_Encode, X_distance, Y_distance; //�ĸ�����ƽ��λ�� ,x,y�����������ۻ�ֵ ,x��y�����
float KX = 1, KY = 1;

void Encode_distance(float dt)
{
    dt = dt * 0.001f;

    wheel_s[0] = wheel_s[0] + ((Encode_zhi[0] + Encode_zhi_last[0]) * dt / 2.0f);
    wheel_s[1] = wheel_s[1] + ((Encode_zhi[1] + Encode_zhi_last[1]) * dt / 2.0f);
    wheel_s[2] = wheel_s[2] + ((Encode_zhi[2] + Encode_zhi_last[2]) * dt / 2.0f);
    wheel_s[3] = wheel_s[3] + ((Encode_zhi[3] + Encode_zhi_last[3]) * dt / 2.0f);

    Encode_zhi_last[0] = Encode_zhi[0];
    Encode_zhi_last[1] = Encode_zhi[1];
    Encode_zhi_last[2] = Encode_zhi[2];
    Encode_zhi_last[3] = Encode_zhi[3];

    average_distance = (wheel_s[0] + wheel_s[1] + wheel_s[2] + wheel_s[3]) / 4.0f;
    Y_Encode = (wheel_s[0] + wheel_s[1] + wheel_s[2] + wheel_s[3]) / 4.0f;
    X_Encode = (wheel_s[3] - wheel_s[1] + wheel_s[0] - wheel_s[2]) / 4.0f;

    X_distance = KX * X_Encode;
    Y_distance = KY * Y_Encode;
}
