#ifndef __MOTOR_H
#define __MOTOR_H
#include "sys.h"

#define motorA1 PAout(5)
#define motorA2 PAout(3)
#define motorB1 PEout(3)
#define motorB2 PEout(2)
#define motorC1 PAout(2)
#define motorC2 PAout(4)
#define motorD1 PEout(0)
#define motorD2 PEout(1)

extern float motor_target_speed[4];
extern float wheel_s[4];                               //四个轮子编码器积分结果
extern float average_distance, X_distance, Y_distance; //四个轮子平均位移 ,x,y轴位移

#define ENCODER_TIM_PERIOD (u16)(65535)
void Encoder_Init_TIM2(void);
void Encoder_Init_TIM3(void);
void Encoder_Init_TIM4(void);
void Encoder_Init_TIM5(void);
int Read_Encoder(u8 TIMX);
void Motor_PWM_Init(u16 arr, u16 psc);
void MOTOR_GPIO_Config(void);
void SetMotor_PWM(float motor_a, float motor_b, float motor_c, float motor_d);
void Encode_distance(float dt);

#endif
