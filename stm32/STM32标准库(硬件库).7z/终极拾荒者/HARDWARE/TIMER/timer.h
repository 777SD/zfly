#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"


extern int jishu1,jishu2,jishu3;   //计数
extern u8 jishu1_flag,jishu2_flag,jishu3_flag;             //计数标志位
extern float Encode_zhi[4],Encode_zhi_last[4];

void TIM6_Int_Init(u16 arr,u16 psc);
void TIM7_Int_Init(u16 arr,u16 psc);
void TIM5_CH1_Cap_Init(u32 arr,u16 psc);

#endif
