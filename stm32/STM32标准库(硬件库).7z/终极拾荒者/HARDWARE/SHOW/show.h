#ifndef __SYS_H
#define __SYS_H

void Init(void);
void show(void);

void Send_data(USART_TypeDef * USARTx,u8 *s,u32 len);

#endif



