#include "sys.h"
uint8_t flag=0;
uint8_t cout=0;
uint8_t coutall=0;
uint8_t cout1=0;
uint8_t cout2=0;
uint8_t cout3=0;
uint8_t cout4=0;
uint8_t u1=0;

extern uint8_t full;
void Init(void)
{
    SystemInit();                   //=====ϵͳ��ʼ��
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
    delay_init(168);                            //��ʼ����ʱ����
    LED_Init();                 //��ʼ��LED
    uart_init(115200);                          //��ʼ�����ڲ�����Ϊ115200
//    usart3_init(115200);            //��������ģ���VOFAͨ��
    uart2_init(115200);             //������ͷ�շ����ڳ�ʼ��
    KEY_Init();
    OLED_Init(); 
    OLED_Clear();
	  InfrarePSwitch_Init();			//��������ʼ��
	  Motor_PWM_Init(99, 839);
	//MOTOR_GPIO_Config();
    TIM9_PWM_Init(20000 - 1, 84 - 1);
    TIM10_PWM_Init(20000 - 1, 84 - 1); 
	//TIM13_14_PWM_Init(20000 - 1, 84 - 1);
    //HCSR04_TRIG_Init();
    TIM5_CH1_Cap_Init(0XFFFFFFFF, 84 - 1); //��1Mhz��Ƶ�ʼ���
    //SetMotor_PWM(70,70,70,70);
   
   // TIM_SetCompare2(TIM9, servo_set(300));//�¶��
	//	Delay_ms(5000);
//	TIM_SetCompare1(TIM9, servo_set(50));
//    TIM_SetCompare2(TIM9, servo_set(90));
//	Delay_ms(4000);
//	TIM_SetCompare1(TIM9, servo_set(200));
//    TIM_SetCompare2(TIM9, servo_set(90));
	
	Buzzer_Init();
//	Buzzer_ON();
//	Delay_ms(500);
//	Buzzer_OFF();
	
	
	
    TIM6_Int_Init(10 - 1, 8400 - 1);        //10ms��ʱ���жϣ����治���ټӶ���
    TIM7_Int_Init(20 - 1, 8400 - 1);            //20ms��ʱ���ж�
   
}  

void show(void)
{

	InfrarePSwitch_Check();//����Ƿ����� ���� 
	Delay_ms(500);
	
    if (Rxshu1 == 1)
    {   
        Rxshu1 = 0;
        delay_ms(900);
        if (Rxshu1 == 1)
        {
			TIM_SetCompare1(TIM9, servo_set(320));//�ɻ���
            TIM_SetCompare2(TIM9, servo_set(195));
			flag=1;
			SetMotor_PWM(0,0,0,0);
        }
		
    }

    else if (Rxshu1 == 2)
    {
        Rxshu1 = 0;
        delay_ms(900);
        if (Rxshu1 == 2)
        {

			TIM_SetCompare1(TIM9, servo_set(60));//��������
            TIM_SetCompare2(TIM9, servo_set(195));
			flag=2;
			SetMotor_PWM(0,0,0,0);
			
        }
		
    }

    else if (Rxshu1 == 3)
    {
        Rxshu1 = 0;
        delay_ms(900);
        if (Rxshu1 == 3)
        {
			TIM_SetCompare1(TIM9, servo_set(45));//�к�����
            TIM_SetCompare2(TIM9, servo_set(110));
			delay_ms(900);
			flag=3;
			SetMotor_PWM(0,0,0,0);
        }
		
    }

    else if (Rxshu1 == 4)
    {
        Rxshu1 = 0;
        delay_ms(900);
        if (Rxshu1 == 4)
        {
            TIM_SetCompare1(TIM9, servo_set(330));//��������
            TIM_SetCompare2(TIM9, servo_set(120));
			delay_ms(900);
			flag=4;
			SetMotor_PWM(0,0,0,0);
        }
		
    }



    else
    {

	   if(flag==1)
	   {
		  cout++;
		  u1=++cout1;
		  coutall=cout1+cout2+cout3+cout4;
		   if(cout>1)
		 {
			GPIO_ResetBits(GPIOD,GPIO_Pin_12);
			Delay_ms(1000);
			GPIO_SetBits(GPIOD,GPIO_Pin_12);	
		 }
	
	  }
	  else if(flag==2)
	  {
			u1=++cout2;
			coutall=cout1+cout2+cout3+cout4;
			
	  }
	  else if(flag==3)
	  {
			u1=++cout3;
			coutall=cout1+cout2+cout3+cout4;
			
	  }
	  else if(flag==4)
	  {
			u1=++cout4;
			coutall=cout1+cout2+cout3+cout4;
	  }
	   USART2_TX(flag,u1,coutall,full);
	   TIM_SetCompare1(TIM9, servo_set(195));
       TIM_SetCompare2(TIM9, servo_set(90));
	   delay_ms(1000);
		flag=0;
		Delay_ms(1500);
		SetMotor_PWM(85,85,85,85);
		Delay_ms(2500);
		SetMotor_PWM(0,0,0,0);
        Delay_ms(100);

    }
	


      OLED_Clear();
      OLED_ShowString(1,1,"message");
	  OLED_ShowNum(2, 10, Rxshu1, 3);
      OLED_ShowNum(3, 10, cout, 3);

    delay_ms(500);
}



