#ifndef __FUNCTION_H
#define __FUNCTION_H
#include "sys.h"

int myabs(int a);
float target_limit_float(float insert,float low,float high);
int target_limit_int(int insert,int low,int high);


#endif



