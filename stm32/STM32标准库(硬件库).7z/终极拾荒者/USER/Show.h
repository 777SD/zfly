#ifndef SHOW_H
#define SHOW_H
void Init(void);
void show(void);


#endif
