#ifndef   _SPI_H
#define   _SPI_H

#include "stdint.h"

void SPI_GPIO_Init(void);
uint8_t SPI2_WriteReadByte(uint8_t data);

#endif

