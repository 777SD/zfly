#ifndef   _EXIT_H
#define   _EXIT_H

void Exit_Init(void);

#endif

