#ifndef __OPENMV_H
#define __OPENMV_H
#define OpenMV_Rx_Width 32  //��ע�⡿
#include "main.h"
extern uint16_t OpenMV_Rx_BUF[OpenMV_Rx_Width];
extern int16_t ValueX, ValueY;
#endif
