/*
 * rbt_date.c
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */
#include "blue.h"
#include "u3.h"
#include "string.h"

blue_AT Roboot_AT;

void Roboot_DateProcessing(void)
{
	Roboot_AT.Advance = roboot.advance;
	Roboot_AT.Left    = roboot.left;
	Roboot_AT.Right   = roboot.right;
	Roboot_AT.Back    = roboot.back;

}

void Roboot_DateReset(void)
{
	Roboot_AT.Advance = 0;
	Roboot_AT.Left    = 0;
	Roboot_AT.Right   = 0;
	Roboot_AT.Back    = 0;

}


