/*
 * rbt_date.h
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */

#ifndef ROBOOT_DATE_RBT_DATE_H_
#define ROBOOT_DATE_RBT_DATE_H_

void Roboot_DateProcessing(void);

#endif /* ROBOOT_DATE_RBT_DATE_H_ */
