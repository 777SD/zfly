/*
 * blue.h
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */

#ifndef ROBOOT_CONTROL_BLUE_H_
#define ROBOOT_CONTROL_BLUE_H_


typedef struct{
	int Advance;
	int Left;
	int Right;
	int Back;
}blue_AT;

typedef struct
{
	double advance;
	double left;
	double right;
	double back;

}blue_date;



#endif /* ROBOOT_CONTROL_BLUE_H_ */
