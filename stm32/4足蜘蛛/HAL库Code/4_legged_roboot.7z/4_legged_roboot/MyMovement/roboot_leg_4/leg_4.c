/*
 * leg_4.c
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */

#include "main.h"
#include "blue.h"
#include "tim.h"
#include "gpio.h"


void Roboot_Advance(void);
void Roboot_left(void);
void Roboot_right(void);
void Roboot_back(void);



void Roboot_Init(void)
{
/*
 * 打开定时器
 *
 */
	HAL_TIM_Base_Start_IT(&htim1);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_Base_Start_IT(&htim3);
	HAL_TIM_Base_Start_IT(&htim4);

/*
 * 打开PWM通道
 *
 */
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);

	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);

	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);

	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_4);

/*
 * 设置通道占空比
 *
 */
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 500);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 500);
}

void Roboot_Move(void)
{


}



void Roboot_Advance(void)
{

	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 500);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 500);

}



void Roboot_left(void)
{

	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 500);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 500);


}


void Roboot_right(void)
{


	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 500);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 500);

}



void Roboot_back(void)
{

	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 500);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 500);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 500);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 500);

}

