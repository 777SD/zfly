/*
 * leg_4.h
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */

#ifndef ROBOOT_LEG_4_LEG_4_H_
#define ROBOOT_LEG_4_LEG_4_H_
void Roboot_Init(void);
void Roboot_Advance(void);
void Roboot_left(void);
void Roboot_right(void);
void Roboot_back(void);
void Roboot_Move(void);

#endif /* ROBOOT_LEG_4_LEG_4_H_ */
