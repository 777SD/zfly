/*
 * u3.h
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */

#ifndef UART_U3_H_
#define UART_U3_H_

/* My CODE BEGIN Includes */
#include "blue.h"
/* My CODE END Includes */


#define SBUS_DATA_SIZE      4      // 4字节
void Bluetooth_IT_Open();
void Bluetooth_UARTE5_Callback(void);


extern blue_date roboot;

#endif /* UART_U3_H_ */
