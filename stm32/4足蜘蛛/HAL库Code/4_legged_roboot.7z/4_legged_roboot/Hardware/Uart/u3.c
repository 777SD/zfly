/*
 * u3.c
 *
 *  Created on: May 27, 2024
 *      Author: SGM
 */



#include "main.h"
#include "u3.h"
#include "blue.h"
#include "usart.h"
#include "stdlib.h"
#include "string.h"


uint8_t PC_buf[1] = {0};
uint8_t rx_flag = 0;
char rxbuf_u3[SBUS_DATA_SIZE]={0};//串口以char类型传输
int i=0;

blue_date roboot;
void Bluetooth_IT_Open()
{
	HAL_UARTEx_ReceiveToIdle_IT(&huart3,PC_buf,1);
}
void Bluetooth_UARTE5_Callback(void)
{

	//advance数据	 double advance;前进
	if(PC_buf[0] == 'A' || rx_flag == 1)//A是包头
	{

		if(PC_buf[0] == 'E')//E是包尾
		{
			rx_flag = 0;
			i = 0;
			roboot.advance =atof(rxbuf_u3);
			memset(rxbuf_u3,0,sizeof(rxbuf_u3));
			return;
		}
		rx_flag =  1;
		if(PC_buf[0] != 'A') rxbuf_u3[i++] = PC_buf[0];

	}


	//left数据 double left;左转
	if(PC_buf[0] == 'L' || rx_flag == 2)//L是包头
	{

		if(PC_buf[0] == 'T')//T是包尾
		{
			rx_flag = 0;
			i = 0;
			roboot.left =atof(rxbuf_u3);
			memset(rxbuf_u3,0,sizeof(rxbuf_u3));
			return;
		}
		rx_flag = 2;
		if(PC_buf[0] != 'L') rxbuf_u3[i++] = PC_buf[0];

	}


	//right数据 double right;右转
	if(PC_buf[0] == 'R' || rx_flag == 3)//R是包头
	{

		if(PC_buf[0] == 'H')//H是包尾
		{
			rx_flag = 0;
			i = 0;
			roboot.right =atof(rxbuf_u3);
			memset(rxbuf_u3,0,sizeof(rxbuf_u3));
			return;
		}
		rx_flag = 3;
		if(PC_buf[0] != 'R') rxbuf_u3[i++] = PC_buf[0];

	}

	//back数据 double back;后退
	if(PC_buf[0] == 'B' || rx_flag == 4)//B是包头
	{

		if(PC_buf[0] == 'K')//K是包尾
		{
			rx_flag = 0;
			i = 0;
			roboot.back =atof(rxbuf_u3);
			memset(rxbuf_u3,0,sizeof(rxbuf_u3));
			return;
		}
		rx_flag = 4;
		if(PC_buf[0] != 'B') rxbuf_u3[i++] = PC_buf[0];

	}
}


