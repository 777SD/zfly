#ifndef OLED_OLED_H_
#define OLED_OLED_H_
#include <stdint.h>

#define OLED_ADDRESS 0x78

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowChinese(uint32_t Line,uint32_t Column,uint32_t Number);

void OLED_SendCmd(uint8_t cmd);
void OLED_sendData(uint8_t Data);
void OLED_dot(void);
void OLED_GRAM(void);
void Send_PingDate(uint8_t Data[],int Length);
void OLED_Show(void);


#endif /* OLED_OLED_H_ */
