#include "usart.h"  
#include "LED.h"    

	
void  usart_init(int baudrate)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd (RCC_AHB1Periph_GPIOA,ENABLE); 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	//IO����
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource9,GPIO_AF_USART1);
  GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1); 	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;   //����
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;		 //����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //�ٶȵȼ�
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	
	// ���ô��ڸ������
	USART_InitStructure.USART_BaudRate 	 = baudrate; //������
	USART_InitStructure.USART_WordLength = USART_WordLength_8b; //����λ8λ
	USART_InitStructure.USART_StopBits   = USART_StopBits_1; //ֹͣλ1λ
	USART_InitStructure.USART_Parity     = USART_Parity_No ; //��У��
	USART_InitStructure.USART_Mode 	    = USART_Mode_Rx | USART_Mode_Tx; //���ͺͽ���ģʽ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // ��ʹ��Ӳ��������
	USART_Cmd(USART1,ENABLE);	//ʹ�ܴ���1
	USART_Init(USART1,&USART_InitStructure); //��ʼ������1
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE); 
	//�ж�
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_Init(&NVIC_InitStructure);
	

}
   u8 USART1_RX_BUF[4];
	 u8 USART1_RX_STA=0;
   u8 s=0; 
void USART1_IRQHandler(void)
{
	u8 res; 

	if(USART_GetFlagStatus(USART1,USART_IT_RXNE) != RESET)
		{
			USART_ClearITPendingBit(USART1, USART_IT_RXNE);
			res = USART_ReceiveData(USART1);
			
			USART1_RX_BUF[USART1_RX_STA] = res;	//��¼���յ���ֵ
			USART_SendData(USART1,USART1_RX_STA);
			USART_SendData(USART1,USART1_RX_BUF[USART1_RX_STA]);
			USART1_RX_STA++;
			if(USART1_RX_STA > 3){
				USART1_RX_STA=0;

//				ledalloff();
			}
		}
		
	}

