#include "led.h"  
#include "usart.h"
void LED_Init(void)
{		
	GPIO_InitTypeDef GPIO_InitStructure; //����ṹ��
	RCC_AHB1PeriphClockCmd (RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE |  RCC_AHB1Periph_GPIOF |  RCC_AHB1Periph_GPIOG, ENABLE); 	//��ʼ��GPIOGʱ��	
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;   //���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  //�������
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;	//����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; //�ٶ�ѡ��
	
	//��ʼ�� LED1 ����
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;	 
	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	GPIO_Init(GPIOC, &GPIO_InitStructure);
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  GPIO_Init(GPIOG, &GPIO_InitStructure);
		
}
void ledalloff(){	
   GPIO_SetBits(GPIOD, GPIO_Pin_15);
   GPIO_SetBits(GPIOD, GPIO_Pin_14);
   GPIO_SetBits(GPIOD, GPIO_Pin_13);
   GPIO_SetBits(GPIOD, GPIO_Pin_12);
	 GPIO_SetBits(GPIOD, GPIO_Pin_11);
 	 GPIO_SetBits(GPIOD, GPIO_Pin_10);
	 GPIO_SetBits(GPIOD, GPIO_Pin_9);
	 GPIO_SetBits(GPIOD, GPIO_Pin_8);
   GPIO_SetBits(GPIOD, GPIO_Pin_7);
   GPIO_SetBits(GPIOD, GPIO_Pin_6);
   GPIO_SetBits(GPIOD, GPIO_Pin_5);
   GPIO_SetBits(GPIOD, GPIO_Pin_4);
	 GPIO_SetBits(GPIOD, GPIO_Pin_3);
 	 GPIO_SetBits(GPIOD, GPIO_Pin_2);
	 GPIO_SetBits(GPIOD, GPIO_Pin_1);
	 GPIO_SetBits(GPIOD, GPIO_Pin_0);

	 GPIO_SetBits(GPIOB, GPIO_Pin_0);
	 GPIO_SetBits(GPIOB, GPIO_Pin_1);
	 GPIO_SetBits(GPIOB, GPIO_Pin_2);	
	 GPIO_SetBits(GPIOB, GPIO_Pin_3);	
	 GPIO_SetBits(GPIOB, GPIO_Pin_4);
	 GPIO_SetBits(GPIOB, GPIO_Pin_5);
	 GPIO_SetBits(GPIOB, GPIO_Pin_6);
	 GPIO_SetBits(GPIOB, GPIO_Pin_7);
	 GPIO_SetBits(GPIOB, GPIO_Pin_8);
	 GPIO_SetBits(GPIOB, GPIO_Pin_9);
	 GPIO_SetBits(GPIOB, GPIO_Pin_10);
	 GPIO_SetBits(GPIOB, GPIO_Pin_11);
	 GPIO_SetBits(GPIOB, GPIO_Pin_12);
	 GPIO_SetBits(GPIOB, GPIO_Pin_13);
	 GPIO_SetBits(GPIOB, GPIO_Pin_14);
	 GPIO_SetBits(GPIOB, GPIO_Pin_15);

	 GPIO_SetBits(GPIOC, GPIO_Pin_0);
	 GPIO_SetBits(GPIOC, GPIO_Pin_1);
	 GPIO_SetBits(GPIOC, GPIO_Pin_2);
	 GPIO_SetBits(GPIOC, GPIO_Pin_3);	 
	 GPIO_SetBits(GPIOC, GPIO_Pin_4);
	 GPIO_SetBits(GPIOC, GPIO_Pin_5);
	 GPIO_SetBits(GPIOC, GPIO_Pin_6);
	 GPIO_SetBits(GPIOC, GPIO_Pin_7);	 
	 GPIO_SetBits(GPIOC, GPIO_Pin_8);
	 GPIO_SetBits(GPIOC, GPIO_Pin_9);
	 GPIO_SetBits(GPIOC, GPIO_Pin_10);	 
	 GPIO_SetBits(GPIOC, GPIO_Pin_11);
	 GPIO_SetBits(GPIOC, GPIO_Pin_12);
	 GPIO_SetBits(GPIOC, GPIO_Pin_13);

	 GPIO_SetBits(GPIOG, GPIO_Pin_0);
	 GPIO_SetBits(GPIOG, GPIO_Pin_1);
	 GPIO_SetBits(GPIOG, GPIO_Pin_2);
	 GPIO_SetBits(GPIOG, GPIO_Pin_3);
	 GPIO_SetBits(GPIOG, GPIO_Pin_4);
	 GPIO_SetBits(GPIOG, GPIO_Pin_5);
	 GPIO_SetBits(GPIOG, GPIO_Pin_6);
	 GPIO_SetBits(GPIOG, GPIO_Pin_7);
	 GPIO_SetBits(GPIOG, GPIO_Pin_8);
	 GPIO_SetBits(GPIOG, GPIO_Pin_9);
	 GPIO_SetBits(GPIOG, GPIO_Pin_10);
	 GPIO_SetBits(GPIOG, GPIO_Pin_11);
	 GPIO_SetBits(GPIOG, GPIO_Pin_12);
	 GPIO_SetBits(GPIOG, GPIO_Pin_13);
	 GPIO_SetBits(GPIOG, GPIO_Pin_14);
	 GPIO_SetBits(GPIOG, GPIO_Pin_15);

	 GPIO_SetBits(GPIOE, GPIO_Pin_0);
	 GPIO_SetBits(GPIOE, GPIO_Pin_1);
	 GPIO_SetBits(GPIOE, GPIO_Pin_2);
	 GPIO_SetBits(GPIOE, GPIO_Pin_3);
	 GPIO_SetBits(GPIOE, GPIO_Pin_4);
	 GPIO_SetBits(GPIOE, GPIO_Pin_5);
	 GPIO_SetBits(GPIOE, GPIO_Pin_6);
	 GPIO_SetBits(GPIOE, GPIO_Pin_7);
	 GPIO_SetBits(GPIOE, GPIO_Pin_8);
	 GPIO_SetBits(GPIOE, GPIO_Pin_9);
	 GPIO_SetBits(GPIOE, GPIO_Pin_10);
	 GPIO_SetBits(GPIOE, GPIO_Pin_11);
	 GPIO_SetBits(GPIOE, GPIO_Pin_12);
	 GPIO_SetBits(GPIOE, GPIO_Pin_13);
	 GPIO_SetBits(GPIOE, GPIO_Pin_14);
	 GPIO_SetBits(GPIOE, GPIO_Pin_15);

	 GPIO_SetBits(GPIOF, GPIO_Pin_0);
	 GPIO_SetBits(GPIOF, GPIO_Pin_1);
	 GPIO_SetBits(GPIOF, GPIO_Pin_2);
	 GPIO_SetBits(GPIOF, GPIO_Pin_3);
	 GPIO_SetBits(GPIOF, GPIO_Pin_4);
	 GPIO_SetBits(GPIOF, GPIO_Pin_5);
	 GPIO_SetBits(GPIOF, GPIO_Pin_6);
	 GPIO_SetBits(GPIOF, GPIO_Pin_7);
	 GPIO_SetBits(GPIOF, GPIO_Pin_8);
	 GPIO_SetBits(GPIOF, GPIO_Pin_9);
	 GPIO_SetBits(GPIOF, GPIO_Pin_10);
	 GPIO_SetBits(GPIOF, GPIO_Pin_11);
	 GPIO_SetBits(GPIOF, GPIO_Pin_12);
	 GPIO_SetBits(GPIOF, GPIO_Pin_13);
	 GPIO_SetBits(GPIOF, GPIO_Pin_14);
	 GPIO_SetBits(GPIOF, GPIO_Pin_15);	 
}

void LED_city(u8 a,u8 b){
  	if(a=='A')
	{ GPIO_ResetBits(GPIOD, GPIO_Pin_1);    //֣��
	  if(b=='1') GPIO_ResetBits(GPIOD, GPIO_Pin_3);   //������
	  if(b=='2') GPIO_ResetBits(GPIOD, GPIO_Pin_5);    //�ʵ۹���
	  if(b=='3') GPIO_ResetBits(GPIOD, GPIO_Pin_7);    //������  	
	  if(b=='4') GPIO_ResetBits(GPIOG, GPIO_Pin_10);     //������Ժ 
	}
  	if(a=='B')
	{ GPIO_ResetBits(GPIOG, GPIO_Pin_15);    //����
	  if(b=='1') GPIO_ResetBits(GPIOB, GPIO_Pin_4);   //�����Ϻ�԰ 
	  if(b=='2') GPIO_ResetBits(GPIOB, GPIO_Pin_6);    //���⸮ 
	  if(b=='3') GPIO_ResetBits(GPIOB, GPIO_Pin_8);    //�������  	
	  if(b=='4') GPIO_ResetBits(GPIOE, GPIO_Pin_1);     //��ͤ��԰ 
	}	
    if(a=='C')
	{ GPIO_ResetBits(GPIOE, GPIO_Pin_14);    //����
	  if(b=='1') GPIO_ResetBits(GPIOB, GPIO_Pin_10);   //����ʯ�� 
	  if(b=='2') GPIO_ResetBits(GPIOG, GPIO_Pin_4);    //����ɽ 
	  if(b=='3') GPIO_ResetBits(GPIOG, GPIO_Pin_2);    //�Ͼ�ɽ  	
	  if(b=='4') GPIO_ResetBits(GPIOD, GPIO_Pin_14);     //��̶��Ͽ�� 
	}
  	if(a=='D')
	{ GPIO_ResetBits(GPIOF, GPIO_Pin_12);    //ƽ��ɽ
	  if(b=='1') GPIO_ResetBits(GPIOG, GPIO_Pin_0);   //Ңɽ 
	  if(b=='2') GPIO_ResetBits(GPIOE, GPIO_Pin_7);    //������ 
	  if(b=='3') GPIO_ResetBits(GPIOE, GPIO_Pin_10);    //��������  	
	  if(b=='4') GPIO_ResetBits(GPIOE, GPIO_Pin_12);     //����԰ 
	}
  	if(a=='E')
	{ GPIO_ResetBits(GPIOE, GPIO_Pin_4);    //����
	  if(b=='1') GPIO_ResetBits(GPIOE, GPIO_Pin_2);   //���� 
	  if(b=='2') GPIO_ResetBits(GPIOG, GPIO_Pin_13);    //������ 
	  if(b=='3') GPIO_ResetBits(GPIOE, GPIO_Pin_0);    //̫��ɽ��Ͽ��  	
	  if(b=='4') GPIO_ResetBits(GPIOB, GPIO_Pin_9);     //������ 
	}	
    if(a=='F')
	{ GPIO_ResetBits(GPIOB, GPIO_Pin_7);    //�ױ�
	  if(b=='1') GPIO_ResetBits(GPIOB, GPIO_Pin_5);   //����ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOB, GPIO_Pin_3);    //����ɽ 
	  if(b=='3') GPIO_ResetBits(GPIOG, GPIO_Pin_11);    //�����Ļ�԰  	
	  if(b=='4') GPIO_ResetBits(GPIOG, GPIO_Pin_9);     //����ɽ 
	}	
    if(a=='G')
	{ GPIO_ResetBits(GPIOD, GPIO_Pin_6);    //����
	  if(b=='1') GPIO_ResetBits(GPIOD, GPIO_Pin_4);   //�ȸ��� 
	  if(b=='2') GPIO_ResetBits(GPIOD, GPIO_Pin_2);    //º���� 
	  if(b=='3') GPIO_ResetBits(GPIOD, GPIO_Pin_0);    //����԰  	
	  if(b=='4') GPIO_ResetBits(GPIOC, GPIO_Pin_11);     //�ζ�ɽ
	}
  	if(a=='H')
	{ GPIO_ResetBits(GPIOC, GPIO_Pin_9);    //����
	  if(b=='1') GPIO_ResetBits(GPIOC, GPIO_Pin_7);   //��̨ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOG, GPIO_Pin_8);    //�ϼ�Ī�� 
	  if(b=='3') GPIO_ResetBits(GPIOG, GPIO_Pin_6);    //�¼ҹ� 	
	  if(b=='4') GPIO_ResetBits(GPIOG, GPIO_Pin_5);     //Բ���� 
	}
    if(a=='I')
	{ GPIO_ResetBits(GPIOF, GPIO_Pin_5);    //���
	  if(b=='1') GPIO_ResetBits(GPIOF, GPIO_Pin_3);   //���԰ 
	  if(b=='2') GPIO_ResetBits(GPIOF, GPIO_Pin_1);    //�ݳ���ַ
	  if(b=='3') GPIO_ResetBits(GPIOC, GPIO_Pin_13);    //�ˮС��  	
	  if(b=='4') GPIO_ResetBits(GPIOE, GPIO_Pin_6);     //��ԭ�ɻ�԰ 
	}	
   if(a=='J')
	{ GPIO_ResetBits(GPIOF, GPIO_Pin_10);    //����
	  if(b=='1') GPIO_ResetBits(GPIOF, GPIO_Pin_8);   //����� 
	  if(b=='2') GPIO_ResetBits(GPIOF, GPIO_Pin_13);    //�й������Ļ�԰ 
	  if(b=='3') GPIO_ResetBits(GPIOB, GPIO_Pin_0);    //���կ  	
	  if(b=='4') GPIO_ResetBits(GPIOB, GPIO_Pin_2);     //����Ҥַ����� 
	}
  	if(a=='K')
	{ GPIO_ResetBits(GPIOD, GPIO_Pin_15);    //���
	  if(b=='1') GPIO_ResetBits(GPIOG, GPIO_Pin_3);   //ɳ墺� 
	  if(b=='2') GPIO_ResetBits(GPIOB, GPIO_Pin_11);    //С���� 
	  if(b=='3') GPIO_ResetBits(GPIOE, GPIO_Pin_15);    //������԰  	
	  if(b=='4') GPIO_ResetBits(GPIOE, GPIO_Pin_13);     //�Ͻִ� 
	}
  	if(a=='L')
	{ GPIO_ResetBits(GPIOB, GPIO_Pin_13);    //����Ͽ
	  if(b=='1') GPIO_ResetBits(GPIOB, GPIO_Pin_15);   //���ز���� 
	  if(b=='2') GPIO_ResetBits(GPIOD, GPIO_Pin_9);    //���ݵؿ�Ժ 
	  if(b=='3') GPIO_ResetBits(GPIOD, GPIO_Pin_11);    //ԥ����Ͽ��  	
	  if(b=='4') GPIO_ResetBits(GPIOD, GPIO_Pin_13);     //�ƺӵ�Ͽ 
	}	 
  	if(a=='M')
	{ GPIO_ResetBits(GPIOG, GPIO_Pin_14);    //����
	  if(b=='1') GPIO_ResetBits(GPIOG, GPIO_Pin_12);   //â��ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOE, GPIO_Pin_3);    //��ս�ۼ���� 
	  if(b=='3') GPIO_ResetBits(GPIOE, GPIO_Pin_5);    //���º�  	
	  if(b=='4') GPIO_ResetBits(GPIOF, GPIO_Pin_0);     //��ر��� 
	}	
    if(a=='N')
	{ GPIO_ResetBits(GPIOF, GPIO_Pin_2);    //�ܿ�
	  if(b=='1') GPIO_ResetBits(GPIOF, GPIO_Pin_4);   //�ص��� 
	  if(b=='2') GPIO_ResetBits(GPIOF, GPIO_Pin_6);    //̫��� 
	  if(b=='3') GPIO_ResetBits(GPIOC, GPIO_Pin_3);    //�л���԰  	
	  if(b=='4') GPIO_ResetBits(GPIOC, GPIO_Pin_1);     //���ӹ��� 
	}
	  if(a=='O')
	{ GPIO_ResetBits(GPIOE, GPIO_Pin_11);    //פ����
	  if(b=='1') GPIO_ResetBits(GPIOE, GPIO_Pin_9);   //���ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOE, GPIO_Pin_8);    //�񹵸�������� 
	  if(b=='3') GPIO_ResetBits(GPIOG, GPIO_Pin_1);    //�Ϻ�����  	
	  if(b=='4') GPIO_ResetBits(GPIOF, GPIO_Pin_15);     //��ɽ 
	}
	  if(a=='P')
	{ GPIO_ResetBits(GPIOD, GPIO_Pin_12);    //����
	  if(b=='1') GPIO_ResetBits(GPIOD, GPIO_Pin_10);   //�Ͻ��� 
	  if(b=='2') GPIO_ResetBits(GPIOD, GPIO_Pin_8);    //������ 
	  if(b=='3') GPIO_ResetBits(GPIOB, GPIO_Pin_14);    //��̶��  	
	  if(b=='4') GPIO_ResetBits(GPIOB, GPIO_Pin_12);     //��ʮ��̷ 
	}	
    if(a=='Q')
	{ GPIO_ResetBits(GPIOF, GPIO_Pin_11);    //����
	  if(b=='1') GPIO_ResetBits(GPIOC, GPIO_Pin_4);   //����ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOC, GPIO_Pin_5);    //����� 
	  if(b=='3') GPIO_ResetBits(GPIOB, GPIO_Pin_1);    //������  	
	  if(b=='4') GPIO_ResetBits(GPIOF, GPIO_Pin_14);     //��Ȫ�� 
	}
	  if(a=='R')
	{ GPIO_ResetBits(GPIOG, GPIO_Pin_7);    //��Դ
	  if(b=='1') GPIO_ResetBits(GPIOC, GPIO_Pin_6);   //����ɽ 
	  if(b=='2') GPIO_ResetBits(GPIOC, GPIO_Pin_8);    //������ 
	  if(b=='3') GPIO_ResetBits(GPIOC, GPIO_Pin_10);    //�ƺ���Ͽ  	
	  if(b=='4') GPIO_ResetBits(GPIOC, GPIO_Pin_12);     //С���� 
	}
	
}
 